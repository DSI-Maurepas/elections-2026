import React, { useEffect, useMemo, useState } from 'react';
import { useElectionState } from '../../hooks/useElectionState';
import { useGoogleSheets } from '../../hooks/useGoogleSheets';
import auditService from '../../services/auditService';
import { SHEET_NAMES } from '../../utils/constants';

const PassageSecondTour = () => {
  const { state: electionState, passerSecondTour } = useElectionState();

  // IMPORTANT:
  // useGoogleSheets doit recevoir un identifiant conforme au mapping centralisé (SHEET_NAMES)
  // afin de garantir la cohérence stricte avec les onglets Google Sheets (et éviter les retours vides).
  const { data: candidats, load: loadCandidats, loading: loadingCandidats } = useGoogleSheets(SHEET_NAMES.CANDIDATS);
  const { data: resultats, load: loadResultats, loading: loadingResultats } = useGoogleSheets(SHEET_NAMES.RESULTATS_T1);

  const [classement, setClassement] = useState([]);
  // Candidats en tête (proposition automatique issue du classement T1)
  // ⚠️ La qualification n'est JAMAIS implicite : elle n'est effective qu'après confirmation du passage au 2nd tour.
  const [candidatsTete, setCandidatsTete] = useState([]);
  const [egalite, setEgalite] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  // Passage effectivement confirmé (= tour actuel 2 + 2 candidats qualifiés enregistrés)
  const passageConfirme = useMemo(() => {
    const t = Number(electionState?.tourActuel ?? 1);
    const q = electionState?.candidatsQualifies;
    return t === 2 && Array.isArray(q) && q.length === 2;
  }, [electionState]);

  const idsQualifiesConfirmes = useMemo(() => {
    if (!passageConfirme) return new Set();
    const q = electionState?.candidatsQualifies || [];
    const ids = q
      .map((c) => c?.listeId || c?.id)
      .filter(Boolean);
    return new Set(ids);
  }, [passageConfirme, electionState]);

  // Flag piloté par l'Administration (ElectionsState: secondTourEnabled)
  // Tolérant aux types (booléen, number, string)
  const secondTourEnabled = useMemo(() => {
    if (!electionState) return false;

    const raw =
      electionState.secondTourEnabled ??
      electionState.passageSecondTourEnabled ??
      electionState.t2Enabled ??
      electionState['secondTourEnabled'] ??
      electionState['PassageSecondTour'] ??
      electionState['passageSecondTour'] ??
      electionState['PASSAGE_SECOND_TOUR'];

    if (raw === true) return true;
    if (raw === false) return false;

    if (typeof raw === 'number') return raw === 1;

    if (typeof raw === 'string') {
      const s = raw.trim().toLowerCase();
      if (!s) return false;
      return (
        s === 'true' ||
        s === '1' ||
        s === 'oui' ||
        s === 'vrai' ||
        s === 'actif' ||
        s === 'enabled' ||
        s === 'on' ||
        s === 'yes'
      );
    }

    return false;
  }, [electionState]);

  useEffect(() => {
    loadCandidats?.();
    loadResultats?.();
  }, [loadCandidats, loadResultats]);

  useEffect(() => {
    if (!Array.isArray(resultats) || !Array.isArray(candidats)) return;
    if (resultats.length === 0 || candidats.length === 0) return;

    const totalExprimes = resultats.reduce((sum, r) => sum + (r?.exprimes || 0), 0);

    const candidatsAvecVoix = candidats.map((candidat) => {
      const id = candidat?.listeId || candidat?.id || '';
      const nom = candidat?.nomListe || candidat?.nom || '';
      const voix = resultats.reduce((sum, r) => sum + (r?.voix?.[id] || 0), 0);
      return {
        ...candidat,
        id,
        nom,
        voix,
        pourcentage: totalExprimes > 0 ? (voix / totalExprimes) * 100 : 0,
      };
    });

    candidatsAvecVoix.sort((a, b) => (b.voix || 0) - (a.voix || 0));
    setClassement(candidatsAvecVoix);

    if (candidatsAvecVoix.length >= 2) {
      const premier = candidatsAvecVoix[0];
      const second = candidatsAvecVoix[1];

      if ((premier?.voix || 0) === (second?.voix || 0)) {
        setEgalite(true);
        setCandidatsTete([]);
        setMessage({
          type: 'warning',
          text: '⚠️ Égalité parfaite entre les 2 premiers candidats. Décision admin requise.',
        });
      } else {
        setEgalite(false);
        setCandidatsTete([premier, second]);
        setMessage((prev) => (prev?.type === 'warning' ? null : prev));
      }
    }
  }, [resultats, candidats]);

  const handlePassageT2 = async () => {
    if (!secondTourEnabled) {
      setMessage({
        type: 'warning',
        text: "⛔ Le passage au 2nd tour est désactivé. Active-le via l'Administration.",
      });
      return;
    }

    if (candidatsTete.length !== 2) {
      setMessage({
        type: 'error',
        text: 'Vous devez sélectionner exactement 2 candidats',
      });
      return;
    }

    if (
      window.confirm(
        `Confirmer le passage au 2nd tour avec:\n1. ${candidatsTete[0].nom}\n2. ${candidatsTete[1].nom}`
      )
    ) {
      try {
        setLoading(true);
        await passerSecondTour(candidatsTete);

        // Audit "best effort" (ne doit jamais bloquer le passage)
        try {
          await auditService.log('PASSAGE_SECOND_TOUR', {
            candidats: candidatsTete.map((c) => ({ id: c?.id || c?.listeId, nom: c?.nom || c?.nomListe, voix: c?.voix })),
          });
        } catch (e) {
          console.warn('Audit log failed (PASSAGE_SECOND_TOUR):', e);
        }

        setMessage({
          type: 'success',
          text: '✅ Passage au 2nd tour effectué avec succès',
        });
      } catch (error) {
        setMessage({
          type: 'error',
          text: `Erreur: ${error?.message || 'Erreur inconnue'}`,
        });
      } finally {
        setLoading(false);
      }
    }
  };

  // ====== Styles inline (pour ne pas dépendre d'une feuille CSS externe et éviter les régressions) ======
  const styles = {
    card: {
      background: '#fff',
      borderRadius: 14,
      boxShadow: '0 6px 18px rgba(0,0,0,0.08)',
      padding: 16,
      border: '1px solid rgba(0,0,0,0.06)',
    },
    cardTitle: {
      margin: 0,
      marginBottom: 12,
      fontSize: 18,
      fontWeight: 800,
    },
    tableWrap: {
      overflowX: 'auto',
      borderRadius: 14,
      border: '1px solid rgba(0,0,0,0.06)',
    },
    table: {
      width: '100%',
      borderCollapse: 'separate',
      borderSpacing: 0,
      overflow: 'hidden',
    },
    th: {
      textAlign: 'left',
      fontSize: 12,
      letterSpacing: 0.5,
      textTransform: 'uppercase',
      opacity: 0.9,
      padding: '12px 12px',
      borderBottom: '1px solid rgba(0,0,0,0.08)',
      background: 'rgba(0,0,0,0.03)',
      position: 'sticky',
      top: 0,
      zIndex: 1,
    },
    td: {
      padding: '12px 12px',
      borderBottom: '1px solid rgba(0,0,0,0.06)',
      verticalAlign: 'middle',
    },
    trQualified: {
      background: 'rgba(34, 197, 94, 0.08)', // vert clair
    },
    badge: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 10px',
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 700,
      background: 'rgba(34, 197, 94, 0.12)',
      border: '1px solid rgba(34, 197, 94, 0.35)',
    },
    hintBox: {
      background: 'rgba(0,0,0,0.03)',
      borderRadius: 14,
      boxShadow: '0 6px 18px rgba(0,0,0,0.06)',
      padding: 14,
      border: '1px solid rgba(0,0,0,0.06)',
      marginBottom: 12,
    },
    qualifiesGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
      gap: 12,
      marginTop: 12,
    },
    miniCard: (accent = 'rgba(34,197,94,0.75)') => ({
      background: '#fff',
      borderRadius: 14,
      boxShadow: '0 8px 20px rgba(0,0,0,0.08)',
      padding: 14,
      border: `1px solid rgba(0,0,0,0.06)`,
      outline: `2px solid ${accent}`,
      outlineOffset: -2,
    }),
    miniTop: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 10,
      gap: 10,
    },
    miniRank: {
      fontWeight: 900,
      fontSize: 12,
      textTransform: 'uppercase',
      opacity: 0.8,
      letterSpacing: 0.6,
    },
    miniName: {
      fontWeight: 900,
      fontSize: 16,
      lineHeight: 1.1,
    },
    miniNumber: {
      fontWeight: 900,
      fontSize: 18,
    },
    barWrap: {
      height: 10,
      background: 'rgba(0,0,0,0.06)',
      borderRadius: 999,
      overflow: 'hidden',
    },
    bar: (pct) => ({
      height: '100%',
      width: `${Math.max(0, Math.min(100, pct))}%`,
      background: 'rgba(34,197,94,0.8)',
      borderRadius: 999,
      transition: 'width 450ms ease',
    }),
  };

  const maxVoix = useMemo(() => {
    if (!Array.isArray(classement) || classement.length === 0) return 0;
    return classement.reduce((m, c) => Math.max(m, c?.voix || 0), 0);
  }, [classement]);

  const loadingData = loadingCandidats || loadingResultats;

  return (
    <div className="passage-t2">
      <h2>➡️ Passage au 2nd tour</h2>

      <style>{`
        .tour-info-card{
          margin: 14px 0 0 0;
          padding: 14px;
          border-radius: 14px;
          border: 1px solid rgba(0,0,0,0.06);
          background: rgba(255,255,255,0.92);
          box-shadow: 0 10px 26px rgba(0,0,0,0.06);
        }
        .tour-info-row{
          display:flex;
          gap: 14px;
          flex-wrap: wrap;
          align-items: stretch;
        }
        .tour-info-item{
          flex: 1 1 220px;
          padding: 10px 12px;
          border-radius: 12px;
          background: rgba(0,0,0,0.03);
          border: 1px solid rgba(0,0,0,0.06);
        }
        .tour-info-item .label{
          font-size: 12px;
          font-weight: 800;
          opacity: 0.8;
          text-transform: uppercase;
          letter-spacing: .4px;
        }
        .tour-info-item .value{
          margin-top: 6px;
          font-size: 18px;
          font-weight: 900;
        }
      `}</style>

      {!secondTourEnabled && (
        <div className="message warning" style={{ marginBottom: 12 }}>
          ⛔ Le passage au 2nd tour est actuellement <strong>désactivé</strong>. Active-le via{' '}
          <strong>Administration</strong> (Passage au 2nd tour = Actif / Inactif).
        </div>
      )}

      {loadingData && (
        <div className="message info" style={{ marginBottom: 12 }}>
          Chargement des candidats et des résultats du 1er tour…
        </div>
      )}

      {!loadingData && (
        (!Array.isArray(candidats) || candidats.length === 0 || !Array.isArray(resultats) || resultats.length === 0) && (
          <div className="message warning" style={{ marginBottom: 12 }}>
            ⚠️ Aucune donnée de <strong>candidats</strong> ou de <strong>résultats T1</strong> n&apos;a été trouvée.
            Vérifie l&apos;onglet <strong>{SHEET_NAMES.CANDIDATS}</strong> et <strong>{SHEET_NAMES.RESULTATS_T1}</strong> dans Google Sheets.
          </div>
        )
      )}

      {/* Bloc clair arrondi + ombre portée */}
      <div style={{ ...styles.hintBox, marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontWeight: 900, fontSize: 16 }}>📊 Classement 1er tour</div>
            <div style={{ opacity: 0.85, fontSize: 13, marginTop: 4 }}>
              Les <strong>2 premiers</strong> sont <strong>proposés</strong> pour le 2nd tour.
              <br />
              ✅ La qualification n'est effective <strong>qu'après confirmation</strong> du passage au 2nd tour.
            </div>
          </div>
          {passageConfirme && idsQualifiesConfirmes.size === 2 ? (
            <span style={styles.badge}>✅ 2 qualifiés confirmés</span>
          ) : (
            candidatsTete.length === 2 && !egalite ? (
              <span style={{ ...styles.badge, background: 'rgba(245, 158, 11, 0.12)', border: '1px solid rgba(245, 158, 11, 0.45)' }}>
                ℹ️ 2 premiers détectés
              </span>
            ) : null
          )}
        </div>
      </div>

      {/* Tableau arrondi + 2 qualifiés en vert */}
      <div style={{ ...styles.card, padding: 14, marginBottom: 16 }}>
        <div style={styles.tableWrap}>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Rang</th>
                <th style={styles.th}>Candidat</th>
                <th style={styles.th}>Voix</th>
                <th style={styles.th}>%</th>
                <th style={styles.th}>Qualifié</th>
              </tr>
            </thead>
            <tbody>
              {classement.length === 0 ? (
                <tr>
                  <td style={styles.td} colSpan={5}>
                    {loadingData ? 'Chargement…' : 'Aucun classement disponible (T1).'}
                  </td>
                </tr>
              ) : (
                classement.map((c, index) => {
                  const isQualified = passageConfirme && idsQualifiesConfirmes.has(c?.id);
                  const pctBar = maxVoix > 0 ? ((c?.voix || 0) / maxVoix) * 100 : 0;

                  return (
                    <tr key={c.id} style={isQualified ? styles.trQualified : undefined}>
                      <td style={styles.td}>{index + 1}</td>
                      <td style={styles.td}>
                        <strong>{c.nom}</strong>
                      </td>
                      <td style={styles.td}>
                        <div style={{ display: 'grid', gap: 6 }}>
                          <div style={{ fontWeight: 800 }}>{(c.voix || 0).toLocaleString('fr-FR')}</div>
                          {/* mini graphique (barre animée) */}
                          <div style={styles.barWrap} title="Visualisation relative (voix)">
                            <div style={styles.bar(pctBar)} />
                          </div>
                        </div>
                      </td>
                      <td style={styles.td}>{(c.pourcentage || 0).toFixed(2)}%</td>
                      <td style={styles.td}>{isQualified ? '✅' : '—'}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {egalite && (
          <div className="message warning" style={{ marginTop: 12 }}>
            ⚠️ Égalité parfaite entre les 2 premiers candidats. Décision admin requise.
          </div>
        )}
      </div>

      {message && <div className={`message ${message.type}`}>{message.text}</div>}

      {/* Bloc "Candidats" : confirmés OU proposés */}
      {!egalite && (passageConfirme || candidatsTete.length === 2) && (
        <div style={{ ...styles.card, marginBottom: 16 }}>
          <h3 style={styles.cardTitle}>
            {passageConfirme ? '🏁 Candidats qualifiés pour le 2nd tour (confirmé)' : '🏁 Candidats proposés pour le 2nd tour'}
          </h3>
          <div style={{ opacity: 0.85, fontSize: 13 }}>
            {passageConfirme
              ? 'Passage confirmé : les qualifiés sont figés dans l’état global.'
              : 'Vérifie les noms et les voix avant confirmation.'}
          </div>

          {passageConfirme === false && (
            <div className="message info" style={{ marginTop: 10 }}>
              ℹ️ Tant que le passage n’est pas confirmé, aucun candidat n’est “qualifié”.
            </div>
          )}

          <div style={styles.qualifiesGrid}>
            <div style={styles.miniCard(passageConfirme ? 'rgba(34,197,94,0.65)' : 'rgba(245,158,11,0.55)')}>
              <div style={styles.miniTop}>
                <div style={styles.miniRank}>1er</div>
                <div style={{ ...styles.miniNumber }}>{((passageConfirme ? (electionState?.candidatsQualifies?.[0]?.voix) : candidatsTete[0]?.voix) || 0).toLocaleString('fr-FR')} voix</div>
              </div>
              <div style={styles.miniName}>{(passageConfirme ? (electionState?.candidatsQualifies?.[0]?.nom || electionState?.candidatsQualifies?.[0]?.nomListe) : candidatsTete[0]?.nom) || ''}</div>
              <div style={{ marginTop: 8, opacity: 0.85, fontSize: 13 }}>
                {(((passageConfirme ? (electionState?.candidatsQualifies?.[0]?.pourcentage) : candidatsTete[0]?.pourcentage) || 0)).toFixed(2)}%
              </div>
              <div style={{ marginTop: 10, ...styles.barWrap }}>
                <div style={styles.bar(maxVoix > 0 ? ((((passageConfirme ? (electionState?.candidatsQualifies?.[0]?.voix) : candidatsTete[0]?.voix) || 0) / maxVoix) * 100) : 0)} />
              </div>
            </div>

            <div style={styles.miniCard(passageConfirme ? 'rgba(34,197,94,0.55)' : 'rgba(245,158,11,0.45)')}>
              <div style={styles.miniTop}>
                <div style={styles.miniRank}>2ème</div>
                <div style={{ ...styles.miniNumber }}>{((passageConfirme ? (electionState?.candidatsQualifies?.[1]?.voix) : candidatsTete[1]?.voix) || 0).toLocaleString('fr-FR')} voix</div>
              </div>
              <div style={styles.miniName}>{(passageConfirme ? (electionState?.candidatsQualifies?.[1]?.nom || electionState?.candidatsQualifies?.[1]?.nomListe) : candidatsTete[1]?.nom) || ''}</div>
              <div style={{ marginTop: 8, opacity: 0.85, fontSize: 13 }}>
                {(((passageConfirme ? (electionState?.candidatsQualifies?.[1]?.pourcentage) : candidatsTete[1]?.pourcentage) || 0)).toFixed(2)}%
              </div>
              <div style={{ marginTop: 10, ...styles.barWrap }}>
                <div style={styles.bar(maxVoix > 0 ? ((((passageConfirme ? (electionState?.candidatsQualifies?.[1]?.voix) : candidatsTete[1]?.voix) || 0) / maxVoix) * 100) : 0)} />
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="actions">
        <button
          onClick={handlePassageT2}
          disabled={!secondTourEnabled || loading || egalite || candidatsTete.length !== 2}
          className="btn-primary"
          title={!secondTourEnabled ? "Désactivé : activer via Administration" : undefined}
        >
          {loading
            ? 'Traitement...'
            : !secondTourEnabled
              ? '⛔ Passage au 2nd tour désactivé'
              : '➡️ Confirmer passage au 2nd tour'}
        </button>
      </div>
    </div>
  );
};

export default PassageSecondTour;
