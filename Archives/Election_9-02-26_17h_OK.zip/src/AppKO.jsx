import React, { useState, useEffect, useMemo } from 'react';

// Styles
import "./styles/variables.css";
import "./styles/App.css";
import "./styles/components/navigation.css";
import "./styles/components/components.css";

// Services
import { isBV, getAuthState } from './services/authService';

// Hooks
import { useElectionState } from './hooks/useElectionState';

// Composants
import Navigation from './components/layout/Navigation';
import Footer from './components/layout/Footer';
import Dashboard from './components/dashboard/Dashboard';
import ParticipationSaisie from './components/participation/ParticipationSaisie';
import ParticipationTableau from './components/participation/ParticipationTableau';
import ParticipationStats from './components/participation/ParticipationStats';
import ResultatsSaisieBureau from './components/resultats/ResultatsSaisieBureau';
import ResultatsConsolidation from './components/resultats/ResultatsConsolidation';
import ResultatsValidation from './components/resultats/ResultatsValidation';
import ResultatsClassement from './components/resultats/ResultatsClassement';
import SiegesMunicipal from './components/sieges/SiegesMunicipal';
import SiegesCommunautaire from './components/sieges/SiegesCommunautaire';
import PassageSecondTour from './components/secondTour/PassageSecondTour';
import ConfigurationT2 from './components/secondTour/ConfigurationT2';
import ConfigBureaux from './components/admin/ConfigBureaux';
import ConfigCandidats from './components/admin/ConfigCandidats';
import AuditLog from './components/admin/AuditLog';
import ExportPDF from './components/exports/ExportPDF';
import ExportExcel from './components/exports/ExportExcel';

// ==================== ACCESS GATE ====================
function AccessGate({ onAuthenticated }) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    const loginWithCode = (c) => {
      const parts = String(c || '').trim().toUpperCase().split('@');
      if (parts.length !== 2) return null;
      const [prefix, suffix] = parts;
      if (suffix !== 'ELECTIONS2026') return null;

      if (prefix === 'ADMIN') return { role: 'Admin', bureauId: null };
      if (prefix === 'GLOBAL') return { role: 'Global', bureauId: null };

      const m = prefix.match(/^BV(\d+)$/);
      if (m) return { role: 'BV', bureauId: m[1] };
      return null;
    };

    const auth = loginWithCode(code);
    if (!auth) {
      setError('Code invalide. Format attendu : ADMIN@Elections2026, GLOBAL@Elections2026, ou BV1@Elections2026');
      return;
    }

    localStorage.setItem('elections_auth', JSON.stringify(auth));
    onAuthenticated(auth);
  };

  return (
    <div style={{ maxWidth: '400px', margin: '100px auto', padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
      <h2 style={{ marginBottom: '20px' }}>🔐 Accès sécurisé</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Code d'accès"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          style={{ width: '100%', padding: '10px', marginBottom: '10px', fontSize: '16px' }}
        />
        {error && <div style={{ color: 'red', marginBottom: '10px', fontSize: '14px' }}>{error}</div>}
        <button type="submit" style={{ width: '100%', padding: '10px', backgroundColor: '#1e3c72', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '16px' }}>
          Se connecter
        </button>
      </form>
    </div>
  );
}

// ==================== APP COMPONENT ====================
const App = () => {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [accessAuth, setAccessAuth] = useState(null);
  
  // Hook confirm dialog inline
  const [uiConfirm, setUiConfirm] = useState({ open: false, title: '', message: '', _resolve: null });
  const confirm = (title, message, opts = {}) => {
    return new Promise((resolve) => {
      setUiConfirm({
        open: true,
        title,
        message,
        confirmText: opts.confirmText || 'Confirmer',
        cancelText: opts.cancelText || 'Annuler',
        _resolve: resolve
      });
    });
  };
  
  const { state: electionState, loadState, passerSecondTour, revenirPremierTour } = useElectionState();

  const safeElectionState = electionState || { tourActuel: 1, tour1Verrouille: false, tour2Verrouille: false };

  const isBureauVote = useMemo(() => isBV(accessAuth), [accessAuth]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('elections_auth');
      if (stored) setAccessAuth(JSON.parse(stored));
    } catch (err) {
      console.error('Erreur lecture auth', err);
    }
  }, []);

  useEffect(() => {
    loadState();
  }, [loadState]);

  const isAuthenticated = !!accessAuth;

  const renderAuthGate = () => {
    if (!isAuthenticated) {
      return <div style={{ padding: '20px', textAlign: 'center', background: '#fff3cd', borderRadius: '4px', margin: '20px 0' }}>
        <strong>🔒 Connexion requise</strong>
        <p>Veuillez vous connecter pour accéder à cette page</p>
      </div>;
    }
    return null;
  };

  const renderPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard electionState={safeElectionState} />;
      case "participation":
        return (
          <>
            {renderAuthGate()}
            {isAuthenticated && (
              <>
                {isBureauVote ? (
                  <div className="participation-bv-container">
                    <div className="participation-bv-grid">
                      <ParticipationSaisie electionState={safeElectionState} reloadElectionState={loadState} />
                      <ParticipationTableau electionState={safeElectionState} />
                    </div>
                  </div>
                ) : (
                  <>
                    <ParticipationSaisie electionState={safeElectionState} reloadElectionState={loadState} />
                    <ParticipationTableau electionState={safeElectionState} />
                  </>
                )}
                <ParticipationStats electionState={safeElectionState} isBureauVote={isBureauVote} />
              </>
            )}
          </>
        );
      case "resultats":
        return (
          <>
            {renderAuthGate()}
            {isAuthenticated && (
              <>
                <ResultatsSaisieBureau electionState={safeElectionState} reloadElectionState={loadState} />
                <ResultatsConsolidation electionState={safeElectionState} />
                {!isBureauVote && <ResultatsValidation electionState={safeElectionState} />}
                {!isBureauVote && <ResultatsClassement electionState={safeElectionState} />}
              </>
            )}
          </>
        );
      case "passage-t2":
        return (
          <>
            {renderAuthGate()}
            {isAuthenticated && (
              <>
                <PassageSecondTour
                  electionState={safeElectionState}
                  passerSecondTour={passerSecondTour}
                  revenirPremierTour={revenirPremierTour}
                  accessAuth={accessAuth}
                />
                <ConfigurationT2 electionState={safeElectionState} />
              </>
            )}
          </>
        );
      case "sieges":
        return (
          <>
            {renderAuthGate()}
            {isAuthenticated && (
              <>
                <SiegesMunicipal electionState={safeElectionState} />
                <SiegesCommunautaire electionState={safeElectionState} />
              </>
            )}
          </>
        );
      case "exports":
        return (
          <>
            {renderAuthGate()}
            {isAuthenticated && (
              <>
                <ExportPDF />
                <ExportExcel />
              </>
            )}
          </>
        );
      case "admin":
        return (
          <>
            {renderAuthGate()}
            {isAuthenticated && (
              <>
                <ConfigBureaux />
                <ConfigCandidats />
                <AuditLog />
              </>
            )}
          </>
        );
      default:
        return <Dashboard electionState={safeElectionState} />;
    }
  };

  if (!accessAuth) {
    return <AccessGate onAuthenticated={(a) => setAccessAuth(a)} />;
  }

  return (
    <div className={`app-root theme-tour-${safeElectionState.tourActuel}`}>
      <style>{`
        /* ==================== POLICE UNIFORME POUR TOUS LES TITRES ==================== */
        h2, h3 {
          font-size: 1.25rem !important;
          font-weight: 600 !important;
          margin-bottom: 16px !important;
        }

        /* ==================== LAYOUT BV CÔTE À CÔTE (DESKTOP) ==================== */
        @media (min-width: 1025px) {
          .participation-bv-container {
            width: 100%;
          }
          
          .participation-bv-grid {
            display: grid !important;
            grid-template-columns: 1fr 1fr !important;
            gap: 24px !important;
            align-items: start !important;
          }
          
          /* ==================== ALIGNEMENT VERTICAL DES LIGNES D'HEURES ==================== */
          
          /* Bloc Saisie : hauteur fixe par ligne */
          .participation-bv-grid .participation-saisie table tbody tr {
            height: 52px !important;
          }
          
          .participation-bv-grid .participation-saisie table tbody tr td {
            padding: 8px 12px !important;
            vertical-align: middle !important;
          }
          
          .participation-bv-grid .participation-saisie table tbody tr td input {
            height: 36px !important;
            line-height: 36px !important;
            padding: 0 12px !important;
            margin: 0 !important;
            box-sizing: border-box !important;
          }
          
          /* Bloc Consolidation : même hauteur fixe */
          .participation-bv-grid .participation-tableau--vertical tbody tr {
            height: 52px !important;
          }
          
          .participation-bv-grid .participation-tableau--vertical tbody tr td {
            height: 52px !important;
            padding: 8px 12px !important;
            line-height: 36px !important;
            vertical-align: middle !important;
          }
          
          /* Fix phrase en bas - pas de déformation */
          .participation-bv-grid .hint {
            white-space: normal !important;
            word-wrap: break-word !important;
            overflow-wrap: break-word !important;
            max-width: 100% !important;
          }
        }
      `}</style>

      <Navigation
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        electionState={safeElectionState}
        confirm={confirm}
        accessAuth={accessAuth}
        onLogout={() => {
          localStorage.removeItem('elections_auth');
          setAccessAuth(null);
          setCurrentPage('dashboard');
        }}
      />

      <main className="app-main" role="main">
        {currentPage === "dashboard" ? renderPage() : (
          <div className="page-container">
            {renderPage()}
          </div>
        )}
      </main>

      <Footer />

      {uiConfirm?.open && (
        <div className="confirm-overlay" onClick={() => {
          const r = uiConfirm._resolve;
          setUiConfirm((p) => ({ ...p, open: false, _resolve: null }));
          r?.(false);
        }}>
          <div className="confirm-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="confirm-content">
              <h3>{uiConfirm.title || "Confirmation"}</h3>
              <p>{uiConfirm.message}</p>
            </div>
            <div className="confirm-actions">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  const r = uiConfirm._resolve;
                  setUiConfirm((p) => ({ ...p, open: false, _resolve: null }));
                  r?.(false);
                }}
              >
                {uiConfirm.cancelText || "Annuler"}
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  const r = uiConfirm._resolve;
                  setUiConfirm((p) => ({ ...p, open: false, _resolve: null }));
                  r?.(true);
                }}
              >
                {uiConfirm.confirmText || "Confirmer"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
