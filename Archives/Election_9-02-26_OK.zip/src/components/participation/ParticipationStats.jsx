import React, { useEffect, useMemo, useState } from 'react';
import { useGoogleSheets } from '../../hooks/useGoogleSheets';

/**
 * Statistiques temps réel de la participation
 * ⚠️ CORRECTION (2026-02-09) : Masquage des blocs statistiques avancés pour les BV
 */
const ParticipationStats = ({ electionState, isBureauVote = false }) => {
  // Bureaux
  const { data: bureaux, load: loadBureaux } = useGoogleSheets('Bureaux');

  // Participation (tour 1 / 2)
  const {
    data: participation,
    load: loadParticipation
  } = useGoogleSheets(electionState.tourActuel === 1 ? 'Participation_T1' : 'Participation_T2');

  // Résultats (optionnel pour % blancs / nuls)
  const {
    data: resultats,
    load: loadResultats
  } = useGoogleSheets(electionState.tourActuel === 1 ? 'Resultats_T1' : 'Resultats_T2');

  const heures = useMemo(() => (
    ['09h', '10h', '11h', '12h', '13h', '14h', '15h', '16h', '17h', '18h', '19h', '20h']
  ), []);

  const getNum = (v) => {
    if (v == null) return 0;
    if (typeof v === 'number') return Number.isFinite(v) ? v : 0;

    // Google Sheets peut renvoyer des chaînes avec espaces/nbsp/narrow-nbsp, etc.
    const s = String(v)
      .trim()
      .replace(/[\s\u00A0\u202F]/g, '')
      .replace(',', '.')
      .replace(/[^0-9.\-]/g, '');

    if (s === '' || s === '-' || s === '.' || s === '-.') return 0;
    const n = Number(s);
    return Number.isFinite(n) ? n : 0;
  };

  /**
   * Renvoie la valeur cumulée "fiable" à une heure donnée :
   * - si l'heure est à 0 mais qu'il y a eu des valeurs >0 avant, on considère que c'est "non renseigné" et on garde
   *   la dernière valeur connue (au lieu de redescendre à 0).
   * - sinon on prend la valeur telle quelle.
   *
   * => Pour éviter les aberrations "1000 votants à 16h, puis 0 à 20h".
   */
  const getReliableValueForHour = (bureau, heure, previousMax) => {
    const raw = getNum(bureau[heure]);
    if (raw === 0 && previousMax > 0) {
      return previousMax;
    }
    return raw;
  };

  // Chargement initial
  useEffect(() => {
    loadBureaux();
    loadParticipation();
    loadResultats();
  }, [loadBureaux, loadParticipation, loadResultats]);

  // ---------- 1. TABLEAU D'ÉVOLUTION HORAIRE ----------
  const evolutionData = useMemo(() => {
    const bureauInscrits = bureaux.reduce((acc, b) => {
      if (b && (b.actif === true || b.actif === 'TRUE' || b.actif === 1)) {
        acc[b.id || ''] = Number(b.inscrits) || 0;
      }
      return acc;
    }, {});

    const totalInscrits = Object.values(bureauInscrits).reduce((sum, i) => sum + i, 0);

    const votantsParHeure = heures.map((h) => {
      const match = participation.find((row) => row && row.Heure === h);
      if (!match) return 0;
      let total = 0;
      for (const bid of Object.keys(bureauInscrits)) {
        total += getNum(match[bid]);
      }
      return total;
    });

    const tauxParHeure = votantsParHeure.map((v) => (totalInscrits > 0 ? (v / totalInscrits) * 100 : 0));

    return heures.map((h, i) => ({
      heure: h,
      votants: votantsParHeure[i],
      taux: tauxParHeure[i]
    }));
  }, [participation, bureaux, heures]);

  // ---------- 2. STATS GLOBALES (inscrits, votants, taux, % blancs/nuls) ----------
  const stats = useMemo(() => {
    const activeBureaux = bureaux.filter((b) => b && (b.actif === true || b.actif === 'TRUE' || b.actif === 1));
    const totalInscrits = activeBureaux.reduce((sum, b) => sum + (Number(b.inscrits) || 0), 0);

    let totalVotants = 0;
    const last = evolutionData[evolutionData.length - 1];
    if (last) totalVotants = last.votants;

    const tauxParticipation = totalInscrits > 0 ? (totalVotants / totalInscrits) * 100 : 0;

    // % blancs / nuls (optionnel)
    const totalBlancs = resultats.reduce((sum, r) => sum + (Number(r.blancs) || 0), 0);
    const totalNuls = resultats.reduce((sum, r) => sum + (Number(r.nuls) || 0), 0);

    const pctBlancs = totalVotants > 0 ? (totalBlancs / totalVotants) * 100 : null;
    const pctNuls = totalVotants > 0 ? (totalNuls / totalVotants) * 100 : null;

    // Bureaux min/max
    let bureauMax = null;
    let bureauMin = null;

    activeBureaux.forEach((b) => {
      const inscrits = Number(b.inscrits) || 0;
      if (inscrits === 0) return;

      let votantsBureau = 0;
      if (last) votantsBureau = getNum(last[b.id]);

      const taux = (votantsBureau / inscrits) * 100;

      if (!bureauMax || taux > bureauMax.taux) {
        bureauMax = { bureauNom: b.nom || b.id, inscrits, votants: votantsBureau, taux };
      }
      if (!bureauMin || taux < bureauMin.taux) {
        bureauMin = { bureauNom: b.nom || b.id, inscrits, votants: votantsBureau, taux };
      }
    });

    return {
      totalInscrits,
      totalVotants,
      tauxParticipation,
      pctBlancs,
      pctNuls,
      bureauMax,
      bureauMin
    };
  }, [bureaux, evolutionData, resultats]);

  // ---------- 3. CHIFFRES CLÉS (insights) ----------
  const chiffresCles = useMemo(() => {
    if (bureaux.length === 0 || participation.length === 0) return null;

    const activeBureaux = bureaux.filter((b) => b && (b.actif === true || b.actif === 'TRUE' || b.actif === 1));

    // a) Max/Min progression entre deux heures
    let maxProg = { delta: 0, bureauLabel: '', heureDebut: '', heureFin: '' };
    let minProg = { delta: Infinity, bureauLabel: '', heureDebut: '', heureFin: '' };

    activeBureaux.forEach((b) => {
      const bid = b.id || '';
      const inscrits = Number(b.inscrits) || 0;
      if (!inscrits) return;

      let previousMax = 0;
      heures.forEach((h, idx) => {
        const row = participation.find((r) => r && r.Heure === h);
        if (!row) return;

        const val = getReliableValueForHour(row, bid, previousMax);
        if (val > previousMax) previousMax = val;

        if (idx > 0) {
          const prevRow = participation.find((r) => r && r.Heure === heures[idx - 1]);
          if (!prevRow) return;

          const prevVal = getNum(prevRow[bid]);
          const delta = val - prevVal;

          if (delta > maxProg.delta) {
            maxProg = {
              delta,
              bureauLabel: b.nom || b.id,
              heureDebut: heures[idx - 1],
              heureFin: h
            };
          }
          if (delta < minProg.delta) {
            minProg = {
              delta,
              bureauLabel: b.nom || b.id,
              heureDebut: heures[idx - 1],
              heureFin: h
            };
          }
        }
      });
    });

    // b) Plus forte abstention (inscrits - votants fin de journée)
    let maxAbst = { abst: 0, bureauLabel: '', inscrits: 0 };
    const lastHeure = heures[heures.length - 1];
    const lastRow = participation.find((r) => r && r.Heure === lastHeure);

    activeBureaux.forEach((b) => {
      const bid = b.id || '';
      const inscrits = Number(b.inscrits) || 0;
      if (!inscrits) return;

      let previousMax = 0;
      heures.forEach((h) => {
        const row = participation.find((r) => r && r.Heure === h);
        if (!row) return;
        const val = getReliableValueForHour(row, bid, previousMax);
        if (val > previousMax) previousMax = val;
      });

      const votants = lastRow ? getReliableValueForHour(lastRow, bid, previousMax) : 0;
      const abst = inscrits - votants;

      if (abst > maxAbst.abst) {
        maxAbst = { abst, bureauLabel: b.nom || b.id, inscrits };
      }
    });

    // c) Max/Min taux de participation (votants / inscrits) en fin de journée
    let maxTaux = { taux: 0, votants: 0, inscrits: 0, bureauLabel: '' };
    let minTaux = { taux: 100, votants: 0, inscrits: 0, bureauLabel: '' };

    activeBureaux.forEach((b) => {
      const bid = b.id || '';
      const inscrits = Number(b.inscrits) || 0;
      if (!inscrits) return;

      let previousMax = 0;
      heures.forEach((h) => {
        const row = participation.find((r) => r && r.Heure === h);
        if (!row) return;
        const val = getReliableValueForHour(row, bid, previousMax);
        if (val > previousMax) previousMax = val;
      });

      const votants = lastRow ? getReliableValueForHour(lastRow, bid, previousMax) : 0;
      const taux = (votants / inscrits) * 100;

      if (taux > maxTaux.taux) {
        maxTaux = { taux, votants, inscrits, bureauLabel: b.nom || b.id };
      }
      if (taux < minTaux.taux) {
        minTaux = { taux, votants, inscrits, bureauLabel: b.nom || b.id };
      }
    });

    // d) Heure la plus chargée / la plus calme (delta communal max/min)
    let heuresChargees = {
      maxHeure: { delta: 0, heureDebut: '', heureFin: '' },
      minHeure: { delta: Infinity, heureDebut: '', heureFin: '' }
    };

    heures.forEach((h, idx) => {
      if (idx === 0) return;
      const prevH = heures[idx - 1];
      const row = participation.find((r) => r && r.Heure === h);
      const prevRow = participation.find((r) => r && r.Heure === prevH);
      if (!row || !prevRow) return;

      let deltaTotal = 0;
      activeBureaux.forEach((b) => {
        const bid = b.id || '';
        const v1 = getNum(prevRow[bid]);
        const v2 = getNum(row[bid]);
        deltaTotal += v2 - v1;
      });

      if (deltaTotal > heuresChargees.maxHeure.delta) {
        heuresChargees.maxHeure = { delta: deltaTotal, heureDebut: prevH, heureFin: h };
      }
      if (deltaTotal < heuresChargees.minHeure.delta) {
        heuresChargees.minHeure = { delta: deltaTotal, heureDebut: prevH, heureFin: h };
      }
    });

    return {
      maxProg,
      minProg,
      maxAbst,
      maxTaux,
      minTaux,
      heuresChargees
    };
  }, [bureaux, participation, heures]);

  // ---------- RENDU ----------
  return (
    <div className="participation-stats">
      {/* Titre */}
      <h2 style={{ marginBottom: 16 }}>📊 Statistiques de participation — Tour {electionState.tourActuel}</h2>

      {/* Tableau d'évolution */}
      <div className="table-container">
        <table className="stats-table" role="table" aria-label="Évolution de la participation par heure">
          <thead>
            <tr>
              <th>Heure</th>
              <th>Votants</th>
              <th>Taux (%)</th>
            </tr>
          </thead>
          <tbody>
            {evolutionData.map((d) => (
              <tr key={d.heure}>
                <td>{d.heure}</td>
                <td>{d.votants.toLocaleString('fr-FR')}</td>
                <td>{d.taux.toFixed(2)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ⚠️ CORRECTION : Bureaux extrêmes masqués pour les BV */}
      {!isBureauVote && (
      <div className="extremes-section">
        <h3>🎯 Bureaux extrêmes</h3>

        <div className="extremes-table" role="table" aria-label="Participation maximale et minimale">
          <div className="extremes-row max" role="row">
            <div className="extremes-type" role="cell">
              🏆 <span>Max</span>
            </div>

            <div className="extremes-bureau" role="cell">
              <div className="bureau-name">{stats.bureauMax?.bureauNom || '—'}</div>
              <div className="bureau-details">
                {stats.bureauMax
                  ? `${stats.bureauMax.votants.toLocaleString('fr-FR')} votants / ${stats.bureauMax.inscrits.toLocaleString('fr-FR')} inscrits`
                  : 'Aucune donnée'}
              </div>
            </div>

            <div className="extremes-metric" role="cell">
              <div className="meter" aria-hidden="true">
                <div
                  className="meter-fill"
                  style={{ width: `${Math.min(100, Math.max(0, stats.bureauMax?.taux || 0))}%` }}
                />
              </div>
              <div className="meter-value">{(stats.bureauMax?.taux || 0).toFixed(2)}%</div>
            </div>
          </div>

          <div className="extremes-row min" role="row">
            <div className="extremes-type" role="cell">
              📉 <span>Min</span>
            </div>

            <div className="extremes-bureau" role="cell">
              <div className="bureau-name">{stats.bureauMin?.bureauNom || '—'}</div>
              <div className="bureau-details">
                {stats.bureauMin
                  ? `${stats.bureauMin.votants.toLocaleString('fr-FR')} votants / ${stats.bureauMin.inscrits.toLocaleString('fr-FR')} inscrits`
                  : 'Aucune donnée'}
              </div>
            </div>

            <div className="extremes-metric" role="cell">
              <div className="meter" aria-hidden="true">
                <div
                  className="meter-fill"
                  style={{ width: `${Math.min(100, Math.max(0, stats.bureauMin?.taux || 0))}%` }}
                />
              </div>
              <div className="meter-value">{(stats.bureauMin?.taux || 0).toFixed(2)}%</div>
            </div>
          </div>
        </div>
      </div>
      )}

      {/* Chiffres clés (Insights renommés) */}
      <div className="analysis-section">
        <h3>📌 Chiffres clés</h3>

        {!chiffresCles ? (
          <div className="metric-card">
            <div className="metric-value">Aucune donnée disponible.</div>
          </div>
        ) : (
          <div className="analysis-diagrams">
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">🚀</span>
                <span className="metric-title">Plus forte progression (votants)</span>
              </div>
              <div className="metric-value">
                {chiffresCles.maxProg.bureauLabel} — {chiffresCles.maxProg.heureDebut}→{chiffresCles.maxProg.heureFin} :
                <strong> +{chiffresCles.maxProg.delta.toLocaleString('fr-FR')}</strong>
              </div>
              <div className="mini-bar" aria-hidden="true"><div className="mini-bar-fill" style={{ width: `${Math.min(100, Math.max(0, chiffresCles.maxProg.delta > 0 ? 100 : 0))}%` }} /></div>
            </div>

            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">🐢</span>
                <span className="metric-title">Moins forte progression (votants)</span>
              </div>
              <div className="metric-value">
                {chiffresCles.minProg.bureauLabel} — {chiffresCles.minProg.heureDebut}→{chiffresCles.minProg.heureFin} :
                <strong> +{chiffresCles.minProg.delta.toLocaleString('fr-FR')}</strong>
              </div>
              <div className="mini-bar" aria-hidden="true"><div className="mini-bar-fill" style={{ width: `${Math.min(100, Math.max(0, chiffresCles.maxProg.delta > 0 ? (chiffresCles.minProg.delta / chiffresCles.maxProg.delta) * 100 : 0))}%` }} /></div>
            </div>

            {/* ⚠️ CORRECTION : Blocs masqués pour les BV */}
            {!isBureauVote && (
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">🧍‍♂️</span>
                <span className="metric-title">Plus forte abstention</span>
              </div>
              <div className="metric-value">
                {chiffresCles.maxAbst.bureauLabel} :
                <strong> {chiffresCles.maxAbst.abst.toLocaleString('fr-FR')} abstentions</strong>
                {chiffresCles.maxAbst.inscrits > 0 ? ` (sur ${chiffresCles.maxAbst.inscrits.toLocaleString('fr-FR')} inscrits)` : ''}
              </div>
              <div className="mini-bar" aria-hidden="true"><div className="mini-bar-fill" style={{ width: `${Math.min(100, Math.max(0, chiffresCles.maxAbst.inscrits > 0 ? (chiffresCles.maxAbst.abst / chiffresCles.maxAbst.inscrits) * 100 : 0))}%` }} /></div>
            </div>
            )}

            {!isBureauVote && (
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">🏅</span>
                <span className="metric-title">% votants le plus élevé</span>
              </div>
              <div className="metric-value">
                {chiffresCles.maxTaux.bureauLabel} :
                <strong> {chiffresCles.maxTaux.taux.toFixed(2)}%</strong>
                {' '}({chiffresCles.maxTaux.votants.toLocaleString('fr-FR')} / {chiffresCles.maxTaux.inscrits.toLocaleString('fr-FR')})
              </div>
              <div className="mini-bar" aria-hidden="true"><div className="mini-bar-fill" style={{ width: `${Math.min(100, Math.max(0, chiffresCles.maxTaux.taux))}%` }} /></div>
            </div>
            )}

            {!isBureauVote && (
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">🧊</span>
                <span className="metric-title">% votants le plus faible</span>
              </div>
              <div className="metric-value">
                {chiffresCles.minTaux.bureauLabel} :
                <strong> {chiffresCles.minTaux.taux.toFixed(2)}%</strong>
                {' '}({chiffresCles.minTaux.votants.toLocaleString('fr-FR')} / {chiffresCles.minTaux.inscrits.toLocaleString('fr-FR')})
              </div>
              <div className="mini-bar" aria-hidden="true"><div className="mini-bar-fill" style={{ width: `${Math.min(100, Math.max(0, chiffresCles.minTaux.taux))}%` }} /></div>
            </div>
            )}

            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">⏱️</span>
                <span className="metric-title">Heure la plus chargée / la plus calme</span>
              </div>
              <div className="metric-value">
                <strong>Chargée</strong> : {chiffresCles.heuresChargees.maxHeure.heureDebut}→{chiffresCles.heuresChargees.maxHeure.heureFin}
                {' '}(<strong>+{chiffresCles.heuresChargees.maxHeure.delta.toLocaleString('fr-FR')}</strong>)<br />
                <strong>Calme</strong> : {chiffresCles.heuresChargees.minHeure.heureDebut}→{chiffresCles.heuresChargees.minHeure.heureFin}
                {' '}(<strong>+{chiffresCles.heuresChargees.minHeure.delta.toLocaleString('fr-FR')}</strong>)
              </div>
            </div>

            {!isBureauVote && (
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">✅</span>
                <span className="metric-title">% de votants (communal)</span>
              </div>
              <div className="metric-value">Taux communal : <strong>{stats.tauxParticipation.toFixed(2)}%</strong></div>
            </div>
            )}

            {!isBureauVote && (
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">⚪</span>
                <span className="metric-title">% de blancs</span>
              </div>
              <div className="metric-value">
                {stats.pctBlancs == null ? 'Données non disponibles' : <>Blancs / votants : <strong>{stats.pctBlancs.toFixed(2)}%</strong></>}
              </div>
            </div>
            )}

            {!isBureauVote && (
            <div className="metric-card">
              <div className="metric-head">
                <span className="metric-emoji">⚫</span>
                <span className="metric-title">% de nuls</span>
              </div>
              <div className="metric-value">
                {stats.pctNuls == null ? 'Données non disponibles' : <>Nuls / votants : <strong>{stats.pctNuls.toFixed(2)}%</strong></>}
              </div>
            </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ParticipationStats;
