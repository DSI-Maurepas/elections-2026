// src/components/resultats/ResultatsSaisieBureau.jsx
import React, { useEffect, useState, useCallback } from 'react';
import GoogleSheetsService from '../../services/googleSheetsService';
import { getAuthState, isBV } from '../../services/authService';

// Verrouillage BV : saisie uniquement sur son bureau

export default function ResultatsSaisieBureau() {
  const auth = getAuthState();
  const forcedBureauId = isBV(auth) ? auth.bureauId : null;

  const [bureauId, setBureauId] = useState(forcedBureauId || 1);
  const [candidats, setCandidats] = useState([]);
  const [voix, setVoix] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (forcedBureauId) {
      setBureauId(forcedBureauId);
    }
  }, [forcedBureauId]);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const candidatsRange = 'Candidats!A2:B';
      const resultatsRange = `Resultats_BV${bureauId}!A2:B`;

      const cands = await GoogleSheetsService.getData(candidatsRange);
      const res = await GoogleSheetsService.getData(resultatsRange, bureauId);

      setCandidats(cands);
      setVoix(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [bureauId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleBlur = async (index, value) => {
    const newVoix = [...voix];
    newVoix[index][1] = value;
    setVoix(newVoix);

    try {
      const range = `Resultats_BV${bureauId}!B${index + 2}`;
      await GoogleSheetsService.updateRange(range, [[value]], bureauId);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div>
      <h2>Résultats — Bureau {bureauId}</h2>

      {!forcedBureauId && (
        <select value={bureauId} onChange={(e) => setBureauId(Number(e.target.value))}>
          {Array.from({ length: 13 }).map((_, i) => (
            <option key={i + 1} value={i + 1}>
              Bureau {i + 1}
            </option>
          ))}
        </select>
      )}

      {loading ? (
        <p>Chargement…</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Candidat</th>
              <th>Voix</th>
            </tr>
          </thead>
          <tbody>
            {candidats.map((c, i) => (
              <tr key={i}>
                <td>{c[1]}</td>
                <td>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={voix[i]?.[1] || ''}
                    onChange={(e) => {
                      const newVoix = [...voix];
                      if (!newVoix[i]) newVoix[i] = [c[0], ''];
                      newVoix[i][1] = e.target.value;
                      setVoix(newVoix);
                    }}
                    onBlur={(e) => handleBlur(i, e.target.value)}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
