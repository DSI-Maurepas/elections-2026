// src/components/resultats/ResultatsSaisieBureau.jsx
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import googleSheetsService from '../../services/googleSheetsService';
import auditService from '../../services/auditService';
import { getAuthState, isBV } from '../../services/authService';
import { useElectionState } from '../../hooks/useElectionState';
import { useGoogleSheets } from '../../hooks/useGoogleSheets';

/**
 * Saisie des résultats par bureau (Tour 1 / Tour 2)
 *
 * ⚠️ Non-régressions / exigences:
 * - Pas d'écriture pendant la frappe (aucune validation au onChange).
 * - Écriture uniquement au onBlur (ou action explicite).
 * - Compat BV : un bureau ne peut saisir/mettre à jour que son bureau (contrôlé aussi côté service).
 * - Cohérence Sheets: on utilise Resultats_T1 / Resultats_T2 (pas d'onglets Resultats_BVx).
 */
export default function ResultatsSaisieBureau() {
  const auth = useMemo(() => getAuthState(), []);
  const forcedBureauId = isBV(auth) ? String(auth.bureauId) : null;

  // État global (tour actuel)
  const { state: electionState } = useElectionState();
  const tourActuel = electionState?.tourActuel === 2 ? 2 : 1;
  const resultatsSheet = tourActuel === 2 ? 'Resultats_T2' : 'Resultats_T1';

  // Données de référence
  const { data: bureaux } = useGoogleSheets('Bureaux');
  const { data: candidats } = useGoogleSheets('Candidats');
  const { data: resultats, load: reloadResultats, loading: loadingResultats } = useGoogleSheets(resultatsSheet);

  const [selectedBureauId, setSelectedBureauId] = useState(forcedBureauId || '');

  // Ligne résultats (objet transformé + rowIndex)
  const [row, setRow] = useState(null);

  // Buffers de saisie (string) pour éviter validations pendant frappe
  const [inputsMain, setInputsMain] = useState({
    inscrits: '',
    votants: '',
    blancs: '',
    nuls: '',
    exprimes: '',
  });

  const [inputsVoix, setInputsVoix] = useState({}); // { L1: '123', L2: '0', ... }

  // BV : bureau imposé
  useEffect(() => {
    if (forcedBureauId) setSelectedBureauId(forcedBureauId);
  }, [forcedBureauId]);

  // Options bureaux (respecte la config "actif")
  const bureauOptions = useMemo(() => {
    const list = Array.isArray(bureaux) ? bureaux : [];
    return list
      .filter((b) => b && (b.actif === true || b.actif === 'TRUE' || b.actif === 1))
      .map((b) => ({ id: String(b.id ?? ''), nom: String(b.nom ?? b.id ?? '') }));
  }, [bureaux]);

  // Candidats actifs selon tour
  const candidatsActifs = useMemo(() => {
    const list = Array.isArray(candidats) ? candidats : [];
    const filtered = list.filter((c) => (tourActuel === 1 ? !!c.actifT1 : !!c.actifT2));

    // Ordre stable
    filtered.sort((a, b) => (Number(a.ordre) || 0) - (Number(b.ordre) || 0));

    return filtered;
  }, [candidats, tourActuel]);

  const findRowForBureau = useCallback((bureauId) => {
    const list = Array.isArray(resultats) ? resultats : [];
    return list.find((r) => String(r?.bureauId ?? '') === String(bureauId)) || null;
  }, [resultats]);

  // Alimentation des buffers quand bureau/tour/données changent
  useEffect(() => {
    if (!selectedBureauId) {
      setRow(null);
      setInputsMain({ inscrits: '', votants: '', blancs: '', nuls: '', exprimes: '' });
      setInputsVoix({});
      return;
    }

    const current = findRowForBureau(selectedBureauId);
    setRow(current);

    const nextMain = {
      inscrits: current ? String(current.inscrits ?? '') : '',
      votants: current ? String(current.votants ?? '') : '',
      blancs: current ? String(current.blancs ?? '') : '',
      nuls: current ? String(current.nuls ?? '') : '',
      exprimes: current ? String(current.exprimes ?? '') : '',
    };
    setInputsMain(nextMain);

    const nextVoix = {};
    for (const c of candidatsActifs) {
      const key = String(c?.listeId ?? '').trim();
      if (!key) continue;
      const v = current?.voix?.[key];
      nextVoix[key] = (v === null || v === undefined) ? '' : String(v);
    }
    setInputsVoix(nextVoix);
  }, [selectedBureauId, tourActuel, candidatsActifs, findRowForBureau]);

  const coerceInt = (v) => {
    const s = String(v ?? '').trim();
    if (s === '') return 0;
    const n = parseInt(s, 10);
    return Number.isFinite(n) ? n : 0;
  };

  const buildRowData = useCallback(() => {
    const voix = {};
    for (const c of candidatsActifs) {
      const key = String(c?.listeId ?? '').trim();
      if (!key) continue;
      voix[key] = coerceInt(inputsVoix[key]);
    }

    return {
      bureauId: selectedBureauId,
      inscrits: coerceInt(inputsMain.inscrits),
      votants: coerceInt(inputsMain.votants),
      blancs: coerceInt(inputsMain.blancs),
      nuls: coerceInt(inputsMain.nuls),
      exprimes: coerceInt(inputsMain.exprimes),
      voix,

      // Ne pas écraser les champs existants si présents
      saisiPar: row?.saisiPar ?? '',
      validePar: row?.validePar ?? '',
      timestamp: row?.timestamp ?? '',
    };
  }, [candidatsActifs, inputsMain, inputsVoix, row, selectedBureauId]);

  const saveCurrentRow = useCallback(async (fieldLabelForAudit) => {
    if (!selectedBureauId) return;

    const rowData = buildRowData();

    // Écriture : update si existe, sinon append
    if (row && (row.rowIndex !== undefined && row.rowIndex !== null)) {
      await googleSheetsService.updateRow(resultatsSheet, row.rowIndex, rowData);
    } else {
      await googleSheetsService.appendRow(resultatsSheet, rowData);
    }

    // Audit (non bloquant)
    try {
      await auditService.logAction?.('RESULTATS_SAISIE', {
        tour: tourActuel,
        bureauId: selectedBureauId,
        champ: fieldLabelForAudit || 'SAVE',
      });
    } catch (_) {}

    // Rafraîchir les données de la feuille résultats (cohérence immédiate)
    await reloadResultats();

    // Mettre à jour le "row" local depuis les données rechargées
    const refreshed = findRowForBureau(selectedBureauId);
    setRow(refreshed);
  }, [buildRowData, findRowForBureau, reloadResultats, resultatsSheet, row, selectedBureauId, tourActuel]);

  const onBlurMain = async (field) => {
    try {
      await saveCurrentRow(field);
    } catch (e) {
      console.error(e);
    }
  };

  const onBlurVoix = async (listeId) => {
    try {
      await saveCurrentRow(`voix_${listeId}`);
    } catch (e) {
      console.error(e);
    }
  };

  const loading = loadingResultats;

  return (
    <div style={{ marginTop: 20 }}>
      <h2>Résultats — Saisie bureau (Tour {tourActuel})</h2>

      {!forcedBureauId && (
        <div style={{ margin: '10px 0' }}>
          <label style={{ marginRight: 8 }}>Bureau :</label>
          <select
            value={selectedBureauId}
            onChange={(e) => setSelectedBureauId(String(e.target.value))}
          >
            <option value="">— Sélectionner —</option>
            {bureauOptions.map((b) => (
              <option key={b.id} value={b.id}>
                {b.id} — {b.nom}
              </option>
            ))}
          </select>
        </div>
      )}

      {loading ? (
        <p>Chargement…</p>
      ) : !selectedBureauId ? (
        <p>Choisir un bureau pour saisir les résultats.</p>
      ) : (
        <>
          {/* Bloc principaux */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, minmax(120px, 1fr))', gap: 10, margin: '10px 0 16px' }}>
            {['inscrits', 'votants', 'blancs', 'nuls', 'exprimes'].map((k) => (
              <div key={k}>
                <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 4 }}>{k.toUpperCase()}</div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={inputsMain[k]}
                  onChange={(e) => setInputsMain((prev) => ({ ...prev, [k]: e.target.value }))}
                  onBlur={() => onBlurMain(k)}
                  style={{ width: '100%', padding: 6 }}
                />
              </div>
            ))}
          </div>

          {/* Tableau voix */}
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', borderBottom: '1px solid #ddd', padding: 6 }}>Liste</th>
                <th style={{ textAlign: 'left', borderBottom: '1px solid #ddd', padding: 6 }}>Tête de liste</th>
                <th style={{ textAlign: 'left', borderBottom: '1px solid #ddd', padding: 6 }}>Voix</th>
              </tr>
            </thead>
            <tbody>
              {candidatsActifs.map((c) => {
                const listeId = String(c?.listeId ?? '').trim();
                const nomListe = String(c?.nomListe ?? '').trim();
                const tete = `${String(c?.teteListePrenom ?? '').trim()} ${String(c?.teteListeNom ?? '').trim()}`.trim();

                return (
                  <tr key={listeId || nomListe || Math.random().toString(16).slice(2)}>
                    <td style={{ borderBottom: '1px solid #f0f0f0', padding: 6 }}>{listeId || '—'} {nomListe ? `— ${nomListe}` : ''}</td>
                    <td style={{ borderBottom: '1px solid #f0f0f0', padding: 6 }}>{tete || '—'}</td>
                    <td style={{ borderBottom: '1px solid #f0f0f0', padding: 6, width: 160 }}>
                      <input
                        type="text"
                        inputMode="numeric"
                        value={inputsVoix[listeId] ?? ''}
                        onChange={(e) => setInputsVoix((prev) => ({ ...prev, [listeId]: e.target.value }))}
                        onBlur={() => onBlurVoix(listeId)}
                        style={{ width: '100%', padding: 6 }}
                      />
                    </td>
                  </tr>
                );
              })}
              {candidatsActifs.length === 0 && (
                <tr>
                  <td colSpan={3} style={{ padding: 10, opacity: 0.8 }}>
                    Aucun candidat actif pour le tour {tourActuel}.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}
