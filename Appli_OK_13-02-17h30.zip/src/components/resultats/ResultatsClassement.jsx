import React, { useMemo } from 'react';
import useGoogleSheets from '../../hooks/useGoogleSheets';
import { getAuthState, isBV } from '../../services/authService';

const COLORS = ['#2563eb', '#16a34a', '#f97316', '#a855f7', '#ef4444', '#14b8a6', '#f59e0b'];

const n = (v) => {
  const num = Number(String(v ?? '').replace(',', '.').replace(/\s/g, ''));
  return Number.isFinite(num) ? num : 0;
};

const getCandidateName = (c, idx) => {
  // Priorité : nomListe (court), puis teteListePrenom + teteListeNom, puis fallback
  const nomListe = (c?.nomListe ?? '').toString().trim();
  if (nomListe) return nomListe;
  const prenom = (c?.teteListePrenom ?? '').toString().trim();
  const nom = (c?.teteListeNom ?? '').toString().trim();
  const full = [prenom, nom].filter(Boolean).join(' ');
  if (full) return full;
  // Anciens formats (compatibilité)
  const legacy = c?.nom ?? c?.name ?? c?.Nom ?? c?.label;
  return (legacy && String(legacy).trim()) ? String(legacy).trim() : `Candidat ${idx + 1}`;
};

const getCandidateId = (c, idx) => {
  // Priorité : listeId (champ réel Sheets), puis id/code/key (anciens formats)
  const listeId = c?.listeId ?? c?.id ?? c?.code ?? c?.key;
  if (listeId && String(listeId).trim()) return String(listeId).trim();
  return `L${idx + 1}`;
};

const ResultatsClassement = ({ electionState }) => {
  // Profil (Admin vs BV) : on n'affiche le bloc "Classement officiel - Tour 1" que pour l'ADMIN
  // ⚠️ Ne modifie pas les données : affichage uniquement
  const auth = useMemo(() => getAuthState(), []);
  const isBureau = isBV(auth);

  const tourActuel = electionState?.tourActuel || 1;

  // Deux appels séparés à useGoogleSheets (pattern standard)
  const { data: candidats } = useGoogleSheets('Candidats');
  const { data: resultatsRaw } = useGoogleSheets(tourActuel === 1 ? 'Resultats_T1' : 'Resultats_T2');
  
  const resultats = Array.isArray(resultatsRaw) ? resultatsRaw : [];
  const candidatsArray = useMemo(() => {
    const list = Array.isArray(candidats) ? candidats : [];
    return list.filter((c) => (tourActuel === 1 ? !!c.actifT1 : !!c.actifT2));
  }, [candidats, tourActuel]);

  const totalExprimes = useMemo(() => {
    return resultats.reduce((acc, r) => acc + n(r.exprimes ?? r.Exprimes), 0);
  }, [resultats]);

  const classement = useMemo(() => {
    if (!candidatsArray.length) return [];

    const totals = candidatsArray.map((c, idx) => {
      const id = getCandidateId(c, idx);
      const totalVoix = resultats.reduce((acc, r) => {
        const voixObj = r.voix || r.Voix || {};
        // accepte {L1: 123} ou {"L1_Voix":123}
        const v = voixObj[id] ?? voixObj[`${id}_Voix`] ?? voixObj[`${id}Voix`];
        return acc + n(v);
      }, 0);
      return { id, name: getCandidateName(c, idx), totalVoix };
    });

    const sorted = totals
      .slice()
      .sort((a, b) => b.totalVoix - a.totalVoix)
      .map((c) => ({
        ...c,
        pct: totalExprimes > 0 ? (c.totalVoix / totalExprimes) * 100 : 0,
      }));

    return sorted;
  }, [candidatsArray, resultats, totalExprimes]);

  const SEUIL_QUALIFICATION = 10; // 10% des suffrages exprimés pour se maintenir au 2nd tour
  
  // Candidats qualifiés : tous ceux qui atteignent >= 10%
  const qualifies = classement.filter(c => c.pct >= SEUIL_QUALIFICATION);
  
  // Si moins de 2 listes atteignent 10%, on prend les 2 premières (règle de repli)
  const top2OrQualifies = qualifies.length >= 2 ? qualifies : classement.slice(0, 2);
  
  // Les autres (éliminés) : tous ceux qui ne sont pas qualifiés
  const others = classement.filter(c => !top2OrQualifies.includes(c));

  const classementContent = (
    <>
      {/* Candidats qualifiés (>= 10% ou top 2 si moins de 2 atteignent 10%) */}
      <div className="top3-grid">
        {top2OrQualifies.map((candidat, index) => {
          const rank = classement.findIndex(c => c.id === candidat.id) + 1;
          const color = COLORS[(rank - 1) % COLORS.length];
          const isQualifie = candidat.pct >= SEUIL_QUALIFICATION || rank <= 2;
          return (
            <div
              key={`${candidat.id}-${rank}`}
              className={`top3-card ${isQualifie ? 'qualified' : 'eliminated'}`}
              style={{ borderLeftColor: color }}
            >
              <div className="top3-rank" style={{ color }}>{rank}</div>
              <div className="top3-content">
                <div className="top3-name">{candidat.name}</div>
                <div className="top3-badge">
                  {isQualifie ? (
                    <span className="badge qualified">✅ QUALIFIÉ</span>
                  ) : (
                    <span className="badge eliminated">⛔ ÉLIMINÉ</span>
                  )}
                </div>
              </div>
              <div className="top3-stats">
                <div className="top3-voix">{candidat.totalVoix.toLocaleString('fr-FR')}</div>
                <div className="top3-pct">{candidat.pct.toFixed(2)}%</div>
                {/* Barre de progression proportionnelle au % */}
                <div className="top3-progress-container">
                  <div className="top3-progress-fill" style={{ width: `${candidat.pct}%`, backgroundColor: color }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Autres candidats (tous les éliminés) - COMPACT SUR UNE LIGNE */}
      {others.length > 0 && (
        <div className="classement-list">
          <div className="classement-subtitle">Autres candidats</div>
          {others.map((candidat) => {
            const rank = classement.findIndex(c => c.id === candidat.id) + 1;
            const color = COLORS[(rank - 1) % COLORS.length];
            return (
              <div key={`${candidat.id}-${rank}`} className="classement-item-compact">
                {/* Numéro dans un cercle grisé */}
                <div className="classement-rank-circle" style={{ color }}>{rank}</div>

                {/* Nom du candidat */}
                <div className="classement-name">{candidat.name}</div>

                {/* Voix */}
                <div className="classement-voix">{candidat.totalVoix.toLocaleString('fr-FR')}</div>

                {/* Pourcentage */}
                <div className="classement-pct">{candidat.pct.toFixed(2)}%</div>

                {/* Badge ÉLIMINÉ */}
                <span className="badge eliminated-compact">⛔ ÉLIMINÉ</span>

                {/* Barre de progression proportionnelle */}
                <div className="classement-progress-container">
                  <div className="classement-progress-fill" style={{ width: `${candidat.pct}%`, backgroundColor: color }} />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );

  const shouldShowOfficialWrap = !isBureau && tourActuel === 1;

  return (
    <section className="resultats-section">
      {shouldShowOfficialWrap ? (
        <div
          className="resultats-card classement-officiel"
          style={{
            background: '#ffffff',
            borderRadius: 14,
            boxShadow: '0 6px 18px rgba(0,0,0,0.10)',
            padding: 16,
            border: '1px solid rgba(0,0,0,0.06)',
            marginBottom: 16,
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 12 }}>
            <div style={{ fontSize: 18, fontWeight: 800, lineHeight: 1.2 }}>
              🏆 Classement officiel - Tour 1
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, opacity: 0.85 }}>
              Total des suffrages exprimés : {totalExprimes.toLocaleString('fr-FR')}
            </div>
          </div>

          {/* Encapsule TOUTES les listes (Top 2 + autres) */}
          <div className="resultats-card-body">{classementContent}</div>
        </div>
      ) : (
        classementContent
      )}
    </section>
  );
};

export default ResultatsClassement;
