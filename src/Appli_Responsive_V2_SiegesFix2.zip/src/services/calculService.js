// src/services/calculService.js
// Calculs métier – Élections municipales 2026
// Correctif clé :
// - Taux de participation communal = (Somme des votants à la DERNIÈRE HEURE disponible, tous bureaux) / (Somme des inscrits, tous bureaux)
// - Protection contre NaN / division par 0
// - Compatible Participation_T1 / Participation_T2

const toInt = (v, def = 0) => {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string') {
    const n = parseInt(v.replace(/\s/g, ''), 10);
    return Number.isFinite(n) ? n : def;
  }
  return def;
};

// Détecte les clés de type votants09h ... votants20h
const isVotantsKey = (key) => /^votants\d{2}h$/i.test(key);

// Retourne la clé de la dernière heure présente dans une ligne
const getDerniereHeureKey = (row) => {
  if (!row || typeof row !== 'object') return null;

  const keys = Object.keys(row).filter(isVotantsKey);
  if (!keys.length) return null;

  // Trie par heure croissante (09h -> 20h)
  keys.sort((a, b) => {
    const ha = parseInt(a.match(/\d{2}/)?.[0] || '0', 10);
    const hb = parseInt(b.match(/\d{2}/)?.[0] || '0', 10);
    return ha - hb;
  });

  return keys[keys.length - 1];
};

export const calculService = {
  /**
   * Calcul des agrégats communaux de participation
   * @param {Array<Object>} participationRows
   * @returns {Object} { totalInscrits, totalVotants, tauxParticipation }
   */
  calcParticipationCommune(participationRows = []) {
    const rows = Array.isArray(participationRows) ? participationRows : [];

    // 1) Total des inscrits = somme des inscrits par bureau
    const totalInscrits = rows.reduce(
      (sum, r) => sum + toInt(r?.inscrits, 0),
      0
    );

    // 2) Total des votants = somme des votants à la dernière heure par bureau
    let totalVotants = 0;
    for (const r of rows) {
      const lastHourKey = getDerniereHeureKey(r);
      if (lastHourKey) {
        totalVotants += toInt(r?.[lastHourKey], 0);
      }
    }

    // 3) Taux de participation sécurisé
    const tauxParticipation =
      totalInscrits > 0 ? (totalVotants / totalInscrits) * 100 : 0;

    return {
      totalInscrits,
      totalVotants,
      tauxParticipation
    };
  },

  /**
   * Calcul de la répartition des sièges municipaux
   * Méthode française pour communes de plus de 1000 habitants
   * @param {Array} resultats - Résultats par bureau (Resultats_T1 ou Resultats_T2)
   * @param {Array} candidats - Liste des candidats
   * @param {number} totalSieges - Nombre total de sièges à attribuer
   * @returns {Array} Répartition des sièges par candidat
   */

  /**
   * Calcule la répartition des sièges municipaux (communes >= 1000 habitants)
   * - Prime majoritaire : 50% des sièges (arrondi au supérieur) à la liste arrivée en tête
   * - Reste : proportionnelle à la plus forte moyenne (méthode d'Hondt), seuil 5%
   *
   * IMPORTANT : Compatible avec 2 formats de données :
   * 1) Nouveau format (appli) : resultats[bureau].voix = { L1: 123, L2: 456, ... } + candidats[].listeId / nomListe
   * 2) Ancien format : colonnes bureau['voix_<id>'] + candidats[].id / nom
   */
  calculerSiegesMunicipaux(resultats = [], candidats = [], totalSieges = 33, options = {}) {
    if (!Array.isArray(resultats) || !Array.isArray(candidats) || !Number.isFinite(totalSieges) || totalSieges <= 0) {
      return [];
    }

    const tourActuel = options?.tourActuel; // optionnel (1/2). Si absent, on applique les règles standard.

    // 1) Préparer les listes candidates (id + nom)
    const listes = candidats
      .map(c => {
        const id = (c?.listeId ?? c?.id ?? '').toString().trim();
        const nom = (c?.nomListe ?? c?.nom ?? '').toString().trim() || id;
        const actif = (tourActuel === 2) ? (c?.actifT2 ?? true) : (c?.actifT1 ?? true);
        return { id, nom, actif };
      })
      .filter(l => l.id);

    if (listes.length === 0) return [];

    // 2) Agréger les voix par liste (somme tous bureaux)
    const voixParListe = {};
    listes.forEach(l => {
      voixParListe[l.id] = { listeId: l.id, nom: l.nom, voix: 0 };
    });

    resultats.forEach(bureau => {
      // Format 1 : bureau.voix = { L1: n, L2: n, ... }
      if (bureau && typeof bureau === 'object' && bureau.voix && typeof bureau.voix === 'object') {
        Object.entries(bureau.voix).forEach(([k, v]) => {
          const id = String(k).trim();
          const n = toInt(v, 0);
          if (!voixParListe[id]) {
            // liste présente dans les résultats mais pas dans Candidats => on l'inclut tout de même pour éviter "tableau vide"
            voixParListe[id] = { listeId: id, nom: id, voix: 0 };
          }
          voixParListe[id].voix += n;
        });
        return;
      }

      // Format 2 : colonnes voix_<id>
      listes.forEach(l => {
        const key = `voix_${l.id}`;
        const n = toInt(bureau?.[key], 0);
        voixParListe[l.id].voix += n;
      });
    });

    const resultatsGlobaux = Object.values(voixParListe)
      .filter(x => x.voix > 0)
      .sort((a, b) => b.voix - a.voix);

    if (resultatsGlobaux.length === 0) return [];

    const totalVoix = resultatsGlobaux.reduce((sum, x) => sum + toInt(x.voix, 0), 0);
    if (totalVoix <= 0) return [];

    // % + éligibilité (seuil 5%)
    resultatsGlobaux.forEach(x => {
      x.pourcentage = (x.voix / totalVoix) * 100;
      x.eligible = x.pourcentage >= 5;
    });

    // Au 1er tour, attribution des sièges uniquement si majorité absolue.
    // Si tourActuel est fourni et vaut 1 => on applique strictement.
    // Si tourActuel est absent, on conserve le comportement historique : pas de sièges si aucune liste > 50.
    const gagnant = resultatsGlobaux[0];
    const majoriteAbsolue = gagnant.pourcentage > 50;

    if ((tourActuel === 1 || tourActuel === undefined) && !majoriteAbsolue) {
      // Retourne une liste vide => l'UI affiche "Aucune donnée...".
      // On préfère ce comportement conservateur plutôt qu'un calcul "prévisionnel" pouvant induire en erreur.
      return [];
    }

    // 3) Prime majoritaire
    const prime = Math.ceil(totalSieges / 2);
    const reste = totalSieges - prime;

    const allocations = {};
    resultatsGlobaux.forEach(x => {
      allocations[x.listeId] = 0;
    });

    allocations[gagnant.listeId] = prime;

    // 4) Proportionnelle sur les listes éligibles (seuil 5%), à la plus forte moyenne (d'Hondt)
    const eligibles = resultatsGlobaux.filter(x => x.eligible);

    // Cas extrême : si le gagnant est le seul éligible, il prend tout
    if (eligibles.length === 1) {
      allocations[gagnant.listeId] += reste;
    } else if (reste > 0) {
      // d'Hondt: à chaque siège, on calcule voix / (siegesDejaAttribues + 1)
      for (let i = 0; i < reste; i++) {
        let bestId = null;
        let bestScore = -1;

        eligibles.forEach(l => {
          const s = allocations[l.listeId] || 0;
          const score = l.voix / (s + 1);
          if (score > bestScore) {
            bestScore = score;
            bestId = l.listeId;
          }
        });

        if (bestId) allocations[bestId] = (allocations[bestId] || 0) + 1;
      }
    }

    // 5) Formater la sortie
    return resultatsGlobaux.map(x => ({
      candidatId: x.listeId,   // compat UI existante
      listeId: x.listeId,
      nom: x.nom,
      voix: x.voix,
      pourcentage: x.pourcentage,
      sieges: allocations[x.listeId] || 0,
      methode: x.eligible ? 'Prime majoritaire + plus forte moyenne (seuil 5%)' : 'Sous le seuil de 5%'
    }));
  },

  /**
   * Calcule une répartition des sièges communautaires par liste.
   *
   * NOTE :
   * - Le fléchage communautaire peut impliquer des règles locales (ordre des fléchés) et dépend des textes applicables.
   * - Ici, on propose une répartition "par liste" proportionnelle à la plus forte moyenne (d'Hondt) avec seuil 5%,
   *   sur la base des voix agrégées (mêmes voix que le municipal).
   *
   * Compatible avec :
   * - resultats[bureau].voix = { L1: n, L2: n, ... }
   * - candidats[].listeId / nomListe
   */
  calculerSiegesCommunautaires(resultats = [], candidats = [], totalSieges = 5, options = {}) {
    if (!Array.isArray(resultats) || !Array.isArray(candidats) || !Number.isFinite(totalSieges) || totalSieges <= 0) {
      return [];
    }

    const tourActuel = options?.tourActuel;

    // Listes connues (au moins pour libellés)
    const listes = candidats
      .map(c => {
        const id = (c?.listeId ?? c?.id ?? '').toString().trim();
        const nom = (c?.nomListe ?? c?.nom ?? '').toString().trim() || id;
        const actif = (tourActuel === 2) ? (c?.actifT2 ?? true) : (c?.actifT1 ?? true);
        return { id, nom, actif };
      })
      .filter(l => l.id);

    // Agrégation voix
    const voixParListe = {};
    listes.forEach(l => {
      voixParListe[l.id] = { listeId: l.id, nom: l.nom, voix: 0 };
    });

    resultats.forEach(bureau => {
      if (bureau && typeof bureau === 'object' && bureau.voix && typeof bureau.voix === 'object') {
        Object.entries(bureau.voix).forEach(([k, v]) => {
          const id = String(k).trim();
          const n = toInt(v, 0);
          if (!voixParListe[id]) voixParListe[id] = { listeId: id, nom: id, voix: 0 };
          voixParListe[id].voix += n;
        });
        return;
      }

      // fallback ancien format
      Object.keys(voixParListe).forEach(id => {
        const key = `voix_${id}`;
        voixParListe[id].voix += toInt(bureau?.[key], 0);
      });
    });

    const resultatsGlobaux = Object.values(voixParListe)
      .filter(x => x.voix > 0)
      .sort((a, b) => b.voix - a.voix);

    if (resultatsGlobaux.length === 0) return [];

    const totalVoix = resultatsGlobaux.reduce((sum, x) => sum + toInt(x.voix, 0), 0);
    if (totalVoix <= 0) return [];

    resultatsGlobaux.forEach(x => {
      x.pourcentage = (x.voix / totalVoix) * 100;
      x.eligible = x.pourcentage >= 5;
    });

    const eligibles = resultatsGlobaux.filter(x => x.eligible);
    if (eligibles.length === 0) return [];

    const allocations = {};
    resultatsGlobaux.forEach(x => { allocations[x.listeId] = 0; });

    // d'Hondt sans prime
    for (let i = 0; i < totalSieges; i++) {
      let bestId = null;
      let bestScore = -1;

      eligibles.forEach(l => {
        const s = allocations[l.listeId] || 0;
        const score = l.voix / (s + 1);
        if (score > bestScore) {
          bestScore = score;
          bestId = l.listeId;
        }
      });

      if (bestId) allocations[bestId] = (allocations[bestId] || 0) + 1;
    }

    return resultatsGlobaux.map(x => ({
      candidatId: x.listeId,
      listeId: x.listeId,
      nom: x.nom,
      voix: x.voix,
      pourcentage: x.pourcentage,
      sieges: allocations[x.listeId] || 0,
      methode: x.eligible ? 'Plus forte moyenne (seuil 5%)' : 'Sous le seuil de 5%'
    }));
  },




  /**
   * Formatage sûr d'un pourcentage
   */
  formatPercent(value, decimals = 2) {
    const n = Number(value);
    if (!Number.isFinite(n)) return `0.${'0'.repeat(decimals)}%`;
    return `${n.toFixed(decimals)}%`;
  }
};

export default calculService;
