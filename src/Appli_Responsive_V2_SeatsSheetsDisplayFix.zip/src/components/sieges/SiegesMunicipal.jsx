import React, { useEffect, useMemo, useState } from 'react';
import { useGoogleSheets } from '../../hooks/useGoogleSheets';
import calculService from '../../services/calculService';
import { useElectionState } from '../../hooks/useElectionState';

const SiegesMunicipal = ({ electionState}) => {
  const { state } = useElectionState();
  // Source prioritaire : tableau précalculé dans Google Sheets
  const { data: seatsMunicipal } = useGoogleSheets('Seats_Municipal');

  // Source de repli (calcul automatique) : candidats + résultats consolidés
  const { data: candidats } = useGoogleSheets('Candidats');
  const { data: resultats } = useGoogleSheets(state.tourActuel === 1 ? 'Resultats_T1' : 'Resultats_T2');

  const [sieges, setSieges] = useState([]);
  const [totalSieges, setTotalSieges] = useState(33); // Maurepas : 33 élus

  const seatsMunicipalTour = useMemo(() => {
    const tour = Number(state.tourActuel) || 1;
    return (seatsMunicipal || [])
      .filter(r => Number(r?.tour) === tour)
      .filter(r => (r?.nomListe || r?.listeId))
      .map(r => ({
        candidatId: r.listeId || r.ListeID || String(r.rowIndex ?? ''),
        nom: r.nomListe || r.NomListe || r.listeId || '—',
        voix: Number(r.voix) || 0,
        pourcentage: Number(r.pctVoix) || 0,
        sieges: Number(r.siegesTotal) || 0,
        methode: 'Google Sheets (Seats_Municipal)',
        eligible: !!r.eligible,
        _raw: r
      }));
  }, [seatsMunicipal, state.tourActuel]);

  useEffect(() => {
    // 1) Si le tableau Seats_Municipal est renseigné pour le tour courant : on l'affiche.
    if (seatsMunicipalTour.length > 0) {
      setSieges(seatsMunicipalTour);
      return;
    }

    // 2) Sinon, on tente le calcul automatique (comportement historique)
    if (!resultats?.length || !candidats?.length) {
      setSieges([]);
      return;
    }
    const results = calculService.calculerSiegesMunicipaux(resultats, candidats, totalSieges, { tour: state.tourActuel });
    setSieges(Array.isArray(results) ? results : []);
  }, [seatsMunicipalTour, resultats, candidats, totalSieges, state.tourActuel]);

  return (
    <div className="sieges-municipal">
      <h2>🪑 Répartition des sièges - Conseil Municipal</h2>
      
      <div className="total-sieges">
        <strong>Total sièges à attribuer :</strong> {totalSieges}
      </div>

      <table className="sieges-table">
        <thead>
          <tr>
            <th>LISTE</th>
            <th>Voix</th>
            <th>%</th>
            <th>Sièges</th>
            <th>Méthode</th>
          </tr>
        </thead>
        <tbody>
          {sieges.length === 0 ? (
            <tr>
              <td colSpan={5} style={{ textAlign: 'center', padding: '16px' }}>
                Aucune donnée de sièges disponible (vérifier <strong>Seats_Municipal</strong> ou la consolidation Résultats).
              </td>
            </tr>
          ) : (
            sieges.map(s => (
              <tr key={s.candidatId}>
                <td><strong>{s.nom}</strong></td>
                <td>{Number(s.voix || 0).toLocaleString('fr-FR')}</td>
                <td>{Number(s.pourcentage || 0).toFixed(2)}%</td>
                <td className="sieges-number">{Number(s.sieges || 0)}</td>
                <td>{s.methode}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      <div className="explication">
        <h4>Méthode de calcul :</h4>
        <p>• 50% des sièges à la liste en tête (prime majoritaire)</p>
        <p>• Reste à la proportionnelle à la plus forte moyenne</p>
      </div>
    </div>
  );
};

export default SiegesMunicipal;