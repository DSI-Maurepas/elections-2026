import React, { useEffect, useMemo } from "react";
import { useGoogleSheets } from "../../hooks/useGoogleSheets";
import "./../../styles/components/informations.css";
import InformationsEvolutionHoraire from "./InformationsEvolutionHoraire";

/**
 * Page Informations (lecture seule)
 * - Zéro écriture Google Sheets
 * - Zéro action destructive
 * - Layout optimisé Full HD
 */
export default function Informations({ electionState }) {
  const tourActuel = electionState?.tourActuel === 2 ? 2 : 1;

  // === Données (LECTURE SEULE) ===
  const { data: bureaux, load: loadBureaux } = useGoogleSheets("Bureaux");
  const { data: candidats, load: loadCandidats, error: errorCandidats } = useGoogleSheets("Candidats");
  const { data: participation, load: loadParticipation } = useGoogleSheets(
    tourActuel === 2 ? "Participation_T2" : "Participation_T1"
  );
  const { data: resultats, load: loadResultats } = useGoogleSheets(
    tourActuel === 2 ? "Resultats_T2" : "Resultats_T1"
  );
  const { data: seatsMunicipal, load: loadSeatsMunicipal } = useGoogleSheets("Seats_Municipal");
  const { data: seatsCommunity, load: loadSeatsCommunity } = useGoogleSheets("Seats_Community");

  useEffect(() => {
    loadBureaux({}, { silent: true });
    loadCandidats({}, { silent: true });
    loadParticipation({}, { silent: true });
    loadResultats({}, { silent: true });
    loadSeatsMunicipal({}, { silent: true });
    loadSeatsCommunity({}, { silent: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tourActuel]);

  // === Helpers ===
  const HOURS = useMemo(
    () => [
      "votants09h","votants10h","votants11h","votants12h","votants13h","votants14h",
      "votants15h","votants16h","votants17h","votants18h","votants19h","votants20h",
    ],
    []
  );

  const normalizeBureauId = (value) => {
    if (value === null || value === undefined) return "";
    const s = String(value).trim().toUpperCase();
    const m = s.match(/(\d+)/);
    return m ? m[1] : s;
  };

  const parseTimestamp = (v) => {
    if (v === null || v === undefined) return null;

    if (typeof v === "number" && Number.isFinite(v)) {
      if (v > 1e12) return new Date(v);
      if (v > 1e9) return new Date(v * 1000);
    }

    const s = String(v).trim();
    if (!s) return null;

    const iso = Date.parse(s);
    if (!Number.isNaN(iso)) return new Date(iso);

    const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (m) {
      const dd = Number(m[1]);
      const mm = Number(m[2]) - 1;
      const yyyy = Number(m[3]);
      const hh = Number(m[4] ?? 0);
      const mi = Number(m[5] ?? 0);
      const ss = Number(m[6] ?? 0);
      const d = new Date(yyyy, mm, dd, hh, mi, ss);
      return Number.isNaN(d.getTime()) ? null : d;
    }

    return null;
  };

  const formatDateTime = (d) => {
    if (!d || !(d instanceof Date) || Number.isNaN(d.getTime())) return "";
    try {
      return new Intl.DateTimeFormat("fr-FR", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }).format(d);
    } catch (_) {
      return d.toLocaleString();
    }
  };

  const coerceInt = (v) => {
    if (v == null) return 0;
    if (typeof v === "number") return Number.isFinite(v) ? Math.trunc(v) : 0;
    const s = String(v).trim().replace(/[\s\u00A0\u202F]/g, "").replace(",", ".").replace(/[^0-9.\-]/g, "");
    if (!s || s === "-" || s === "." || s === "-.") return 0;
    const n = Number(s);
    return Number.isFinite(n) ? Math.trunc(n) : 0;
  };

  const pct = (num, den) => {
    const n = Number(num) || 0;
    const d = Number(den) || 0;
    if (d <= 0) return 0;
    return (n / d) * 100;
  };

  const formatInt = (n) => {
    try {
      return new Intl.NumberFormat("fr-FR").format(Number(n) || 0);
    } catch (_) {
      return String(Number(n) || 0);
    }
  };

  const formatPct = (p) => {
    const v = Number(p) || 0;
    return `${v.toFixed(1).replace(".", ",")} %`;
  };

  const getLastCumul = (row) => {
    let last = 0;
    for (const k of HOURS) {
      const val = coerceInt(row?.[k]);
      if (val > 0) last = val;
    }
    return last;
  };

  // === Agrégats ===
  const activeBureaux = useMemo(() => {
    const list = Array.isArray(bureaux) ? bureaux : [];
    return list.filter((b) => b && b.actif === true);
  }, [bureaux]);

  const totalInscrits = useMemo(() => {
    return activeBureaux.reduce((sum, b) => sum + (coerceInt(b?.inscrits) || 0), 0);
  }, [activeBureaux]);

  // Total votants élection précédente (optionnel)
  const previousElectionTotal = 11111; // à remplacer si besoin

  const participationTotal = useMemo(() => {
    const list = Array.isArray(participation) ? participation : [];
    let sum = 0;
    for (const r of list) sum += getLastCumul(r);
    return sum;
  }, [participation, HOURS]);

  const lastParticipationHour = useMemo(() => {
    const list = Array.isArray(participation) ? participation : [];
    let lastKey = null;
    for (const k of HOURS) {
      const hasAny = list.some((r) => coerceInt(r?.[k]) > 0);
      if (hasAny) lastKey = k;
    }
    if (!lastKey) return { key: null, label: "—" };
    const m = String(lastKey).match(/(\d{2})h/i);
    const label = m ? `${m[1]}h` : lastKey;
    return { key: lastKey, label };
  }, [participation, HOURS]);

  const lastParticipationUpdate = useMemo(() => {
    const list = Array.isArray(participation) ? participation : [];
    let best = null;
    for (const r of list) {
      const d = parseTimestamp(r?.timestamp);
      if (d && (!best || d > best)) best = d;
    }
    return best;
  }, [participation]);

  const totauxResultats = useMemo(() => {
    const list = Array.isArray(resultats) ? resultats : [];
    let votants = 0, blancs = 0, nuls = 0, exprimes = 0;
    for (const r of list) {
      votants += coerceInt(r?.votants);
      blancs += coerceInt(r?.blancs);
      nuls += coerceInt(r?.nuls);
      exprimes += coerceInt(r?.exprimes);
    }
    return { votants, blancs, nuls, exprimes };
  }, [resultats]);

  // Référence "votants"
  const votantsReference = useMemo(() => {
    const p = Number(participationTotal) || 0;
    const r = Number(totauxResultats.votants) || 0;
    return Math.max(p, r);
  }, [participationTotal, totauxResultats]);

  const tauxParticipation = useMemo(() => pct(votantsReference, totalInscrits), [votantsReference, totalInscrits]);
  const abstention = useMemo(() => Math.max(0, (totalInscrits || 0) - (votantsReference || 0)), [totalInscrits, votantsReference]);
  const tauxAbstention = useMemo(() => pct(abstention, totalInscrits), [abstention, totalInscrits]);

  // Classement top 5 (lecture seule)
  const topListes = useMemo(() => {
    const res = Array.isArray(resultats) ? resultats : [];
    const cand = Array.isArray(candidats) ? candidats : [];
    if (!res.length) return [];

    const n = (v) => {
      const num = Number(String(v ?? "").replace(",", ".").replace(/\s/g, ""));
      return Number.isFinite(num) ? num : 0;
    };

    const getCandidateName = (c, idx) => {
      const nomListe = (c?.nomListe ?? "").toString().trim();
      if (nomListe) return nomListe;
      const prenom = (c?.teteListePrenom ?? "").toString().trim();
      const nom = (c?.teteListeNom ?? "").toString().trim();
      const full = [prenom, nom].filter(Boolean).join(" ");
      if (full) return full;
      const legacy = c?.nom ?? c?.name ?? c?.Nom ?? c?.label;
      return legacy && String(legacy).trim() ? String(legacy).trim() : `Candidat ${idx + 1}`;
    };

    const getCandidateId = (c, idx) => {
      const listeId = c?.listeId ?? c?.id ?? c?.code ?? c?.key;
      if (listeId && String(listeId).trim()) return String(listeId).trim();
      return `L${idx + 1}`;
    };

    const candidatsActifs = cand.filter((c) => (tourActuel === 1 ? !!c.actifT1 : !!c.actifT2));
    if (!candidatsActifs.length) return [];

    const totalExprimesLocal =
      (totauxResultats?.exprimes ?? 0) ||
      res.reduce((acc, r) => acc + n(r?.exprimes ?? r?.Exprimes), 0);

    const totals = candidatsActifs.map((c, idx) => {
      const id = getCandidateId(c, idx);
      const totalVoix = res.reduce((acc, r) => {
        const voixObj = r?.voix || r?.Voix || {};
        const v = voixObj?.[id] ?? voixObj?.[`${id}_Voix`] ?? voixObj?.[`${id}Voix`];
        return acc + n(v);
      }, 0);
      return { listeId: id, nomListe: getCandidateName(c, idx), voix: totalVoix };
    });

    return totals
      .slice()
      .sort((a, b) => (b.voix || 0) - (a.voix || 0))
      .slice(0, 5)
      .map((x) => ({
        ...x,
        pctVoix: totalExprimesLocal > 0 ? (x.voix / totalExprimesLocal) * 100 : 0,
      }));
  }, [resultats, candidats, tourActuel, totauxResultats]);

  // Sièges
  const seatsByListeId = useMemo(() => {
    const map = new Map();
    const list = Array.isArray(seatsCommunity) ? seatsCommunity : [];
    for (const r of list) {
      const id = String(r?.listeId ?? r?.liste ?? "").trim();
      if (!id) continue;
      map.set(id, { ...r, siegesTotal: coerceInt(r?.siegesTotal ?? r?.sieges ?? 0) });
    }
    return map;
  }, [seatsCommunity]);

  const muniByListeId = useMemo(() => {
    const map = new Map();
    const list = Array.isArray(seatsMunicipal) ? seatsMunicipal : [];
    for (const r of list) {
      const id = String(r?.listeId ?? r?.liste ?? "").trim();
      if (!id) continue;
      map.set(id, { ...r, siegesTotal: coerceInt(r?.siegesTotal ?? r?.sieges ?? 0) });
    }
    return map;
  }, [seatsMunicipal]);

  const tourLabel = tourActuel === 2 ? "Tour 2" : "Tour 1";
  const themeClass = tourActuel === 2 ? "t2" : "t1";

  const bureauxDeclares = useMemo(() => {
    const list = Array.isArray(resultats) ? resultats : [];
    const set = new Set();
    for (const r of list) {
      const id = String(r?.bureauId ?? "").trim();
      const hasData =
        coerceInt(r?.exprimes) > 0 ||
        coerceInt(r?.votants) > 0 ||
        coerceInt(r?.blancs) > 0 ||
        coerceInt(r?.nuls) > 0 ||
        String(r?.timestamp ?? "").trim() !== "";
      if (id && hasData) set.add(id);
    }
    return set.size;
  }, [resultats]);

  const totalBureaux = activeBureaux.length;
  const bureauxRestants = Math.max(0, totalBureaux - bureauxDeclares);

  const lastValidatedBureau = useMemo(() => {
    const list = Array.isArray(resultats) ? resultats : [];
    const bureauxList = Array.isArray(bureaux) ? bureaux : [];

    let best = null;
    let bestRow = null;

    for (const r of list) {
      const ts = parseTimestamp(r?.timestamp);
      if (!ts) continue;
      const validatedBy = String(r?.validePar ?? "").trim();
      if (!validatedBy) continue;

      if (!best || ts > best) {
        best = ts;
        bestRow = r;
      }
    }

    if (!bestRow) return null;

    const rowBureauId = normalizeBureauId(bestRow?.bureauId ?? bestRow?.id ?? "");
    const match = bureauxList.find((b) => normalizeBureauId(b?.id) === rowBureauId);
    const bureauLabel = match?.nom ? `${match.id} — ${match.nom}` : (rowBureauId ? `BV${rowBureauId}` : "—");

    return { bureauLabel, at: best, validatedBy: String(bestRow?.validePar ?? "").trim() };
  }, [resultats, bureaux]);

  return (
    <div className={`info-page ${themeClass}`}>
      <header className="info-header">
        <div className="info-title">
          <div className="info-kicker">Élections Municipales 2026</div>
          <h1>Informations — {tourLabel}</h1>
        </div>

        <div className="info-meta">
          <div className="info-meta-item">
            <div className="label">Bureaux déclarés</div>
            <div className="value">{formatInt(bureauxDeclares)} / {formatInt(totalBureaux)}</div>
            <div className="sub">{bureauxRestants > 0 ? `${formatInt(bureauxRestants)} restants` : "Tous déclarés"}</div>
          </div>

          <div className="info-meta-item">
            <div className="label">Participation</div>
            <div className="value">{formatPct(tauxParticipation)}</div>
            <div className="sub">{formatInt(votantsReference)} votants</div>
          </div>

          <div className="info-meta-item">
            <div className="label">Dernière saisie</div>
            <div className="value">
              {lastParticipationHour?.label && lastParticipationHour.label !== "—" ? `Participation ${lastParticipationHour.label}` : "—"}
            </div>
            <div className="sub">
              {lastParticipationUpdate ? `Maj participation : ${formatDateTime(lastParticipationUpdate)}` : "Maj participation : —"}
              {" • "}
              {lastValidatedBureau ? `Dernier BV validé : ${lastValidatedBureau.bureauLabel}` : "Dernier BV validé : —"}
            </div>
          </div>
        </div>
      </header>

      <section className="info-grid">
        <article className="info-card span-2">
          <div className="card-title">Participation</div>
          <div className="kpis">
            <div className="kpi">
              <div className="kpi-label">Inscrits</div>
              <div className="kpi-value">{formatInt(totalInscrits)}</div>
            </div>
            <div className="kpi">
              <div className="kpi-label">Votants (référence)</div>
              <div className="kpi-value">{formatInt(votantsReference)}</div>
            </div>
            <div className="kpi">
              <div className="kpi-label">Taux de participation</div>
              <div className="kpi-value">{formatPct(tauxParticipation)}</div>
            </div>
            <div className="kpi">
              <div className="kpi-label">Abstention</div>
              <div className="kpi-value">{formatPct(tauxAbstention)}</div>
              <div className="kpi-sub">{formatInt(abstention)} inscrits</div>
            </div>
          </div>
          <div className="note">Lecture seule — données issues des saisies bureaux (sans action métier depuis cette page).</div>
        </article>

        <article className="info-card span-2 info-card-evolution">
          <InformationsEvolutionHoraire
            participationData={participation}
            totalInscrits={totalInscrits}
            previousElectionTotal={previousElectionTotal}
          />
        </article>

        <article className="info-card">
          <div className="card-title">Résultats — Totaux</div>
          <div className="totals">
            <div className="row"><span>Exprimés</span><strong>{formatInt(totauxResultats.exprimes)}</strong></div>
            <div className="row"><span>Blancs</span><strong>{formatInt(totauxResultats.blancs)}</strong></div>
            <div className="row"><span>Nuls</span><strong>{formatInt(totauxResultats.nuls)}</strong></div>
            <div className="row"><span>Votants</span><strong>{formatInt(totauxResultats.votants)}</strong></div>
          </div>
        </article>

        <article className="info-card">
          <div className="card-title">Classement — Top 5 listes</div>
          <div className="rank">
            {topListes.length === 0 ? (
              <div className="empty">
                Données en attente (aucun classement disponible).
                {errorCandidats ? (
                  <span style={{ marginLeft: 6, opacity: 0.85 }}>
                    (Candidats indisponible : {String(errorCandidats)})
                  </span>
                ) : null}
              </div>
            ) : (
              topListes.map((l, i) => {
                const id = String(l?.listeId ?? "").trim();
                const muni = muniByListeId.get(id);
                const comm = seatsByListeId.get(id);

                return (
                  <div key={`${id}-${i}`} className="rank-row">
                    <div className="rank-pos">{i + 1}</div>

                    <div className="rank-main">
                      <div className="rank-name">{l?.nomListe || id || "Liste"}</div>
                      <div className="rank-sub">
                        {formatInt(l?.voix)} voix — {formatPct(l?.pctVoix)}
                      </div>
                    </div>

                    <div className="rank-seats">
                      <div className="seat">
                        <div className="seat-label">Municipal</div>
                        <div className="seat-value">{formatInt(muni?.siegesTotal)}</div>
                      </div>
                      <div className="seat">
                        <div className="seat-label">Communautaire</div>
                        <div className="seat-value">{formatInt(comm?.siegesTotal)}</div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </article>
      </section>

      <section className="info-bottom">
        <div className="info-footnote">
          Synthèse projetée — données issues des écrans Participation / Résultats / Sièges (recomposées, lecture seule).
        </div>
      </section>
    </div>
  );
}
