import React, { useMemo } from "react";

/**
 * Evolution horaire (page Informations)
 * - Barres = delta (votants/heure)
 * - Courbe = cumul total (tous bureaux)
 * - Lecture seule, aucune écriture, aucun polling
 */
export default function InformationsEvolutionHoraire({ participationData }) {
  const HOURS = useMemo(
    () => [
      { key: "votants09h", label: "09h" },
      { key: "votants10h", label: "10h" },
      { key: "votants11h", label: "11h" },
      { key: "votants12h", label: "12h" },
      { key: "votants13h", label: "13h" },
      { key: "votants14h", label: "14h" },
      { key: "votants15h", label: "15h" },
      { key: "votants16h", label: "16h" },
      { key: "votants17h", label: "17h" },
      { key: "votants18h", label: "18h" },
      { key: "votants19h", label: "19h" },
      { key: "votants20h", label: "20h" },
    ],
    []
  );

  const coerceInt = (v) => {
    if (v == null) return 0;
    if (typeof v === "number") return Number.isFinite(v) ? Math.trunc(v) : 0;
    const s = String(v)
      .trim()
      .replace(/[\s\u00A0\u202F]/g, "")
      .replace(",", ".")
      .replace(/[^0-9.\-]/g, "");
    const n = Number(s);
    return Number.isFinite(n) ? Math.trunc(n) : 0;
  };

  const fmt = (n) => new Intl.NumberFormat("fr-FR").format(Number(n) || 0);

  const { cumulSeries, deltaSeries, maxDelta, maxCumul } = useMemo(() => {
    const rows = Array.isArray(participationData) ? participationData : [];

    // cumul total par heure (somme des cumuls bureau)
    const cumul = HOURS.map(({ key, label }) => {
      const total = rows.reduce((sum, r) => sum + coerceInt(r?.[key]), 0);
      return { label, value: total };
    });

    // delta/heure = différence de cumul
    const delta = cumul.map((p, idx) => {
      const prev = idx === 0 ? 0 : cumul[idx - 1].value;
      const d = Math.max(0, p.value - prev);
      return { label: p.label, value: d };
    });

    const maxD = Math.max(1, ...delta.map((d) => d.value));
    const maxC = Math.max(1, ...cumul.map((c) => c.value));

    return {
      cumulSeries: cumul,
      deltaSeries: delta,
      maxDelta: maxD,
      maxCumul: maxC,
    };
  }, [participationData, HOURS]);

  // SVG sizing (normalized 0..100 in X and Y)
  const svgPaths = useMemo(() => {
    const n = cumulSeries.length;
    if (!n) return { line: "", area: "", points: [] };

    const W = 100;
    const H = 100;
    const step = n === 1 ? 0 : W / (n - 1);

    const pts = cumulSeries.map((p, i) => {
      const x = i * step;
      const y = H - (p.value / maxCumul) * H;
      return { x, y };
    });

    // simple smoothing (catmull-rom -> bezier)
    const catmullRom2bezier = (p0, p1, p2, p3) => {
      const c1x = p1.x + (p2.x - p0.x) / 6;
      const c1y = p1.y + (p2.y - p0.y) / 6;
      const c2x = p2.x - (p3.x - p1.x) / 6;
      const c2y = p2.y - (p3.y - p1.y) / 6;
      return `C ${c1x.toFixed(2)} ${c1y.toFixed(2)}, ${c2x.toFixed(2)} ${c2y.toFixed(
        2
      )}, ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
    };

    let d = `M ${pts[0].x.toFixed(2)} ${pts[0].y.toFixed(2)}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[i + 2] || p2;
      d += " " + catmullRom2bezier(p0, p1, p2, p3);
    }

    const area = `${d} L ${pts[pts.length - 1].x.toFixed(2)} ${H} L ${pts[0].x.toFixed(
      2
    )} ${H} Z`;

    return { line: d, area, points: pts };
  }, [cumulSeries, maxCumul]);

  return (
    <div className="info-evolution">
      <div className="info-evolution-head">
        <div className="info-evolution-title">Évolution horaire</div>
        <div className="info-evolution-sub">Delta (votants/heure) + courbe cumul (lissée)</div>
      </div>

      <div className="info-evolution-chart-wrap">
        {/* Bars + labels */}
        <div className="info-bars">
          {deltaSeries.map((d) => {
            const hPct = (d.value / maxDelta) * 100;
            return (
              <div key={d.label} className="info-bar-col">
                <div className="info-bar" style={{ height: `${hPct}%` }} />
                <div className="info-bar-delta">+{fmt(d.value)}</div>
                <div className="info-bar-label">{d.label}</div>
              </div>
            );
          })}
        </div>

        {/* Cumulative overlay */}
        <svg className="info-cumul-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          <path className="info-cumul-area" d={svgPaths.area} />
          <path className="info-cumul-line" d={svgPaths.line} />
          {svgPaths.points.map((p, i) => (
            <circle key={i} className="info-cumul-point" cx={p.x} cy={p.y} r="1.9" />
          ))}
        </svg>
      </div>
    </div>
  );
}
